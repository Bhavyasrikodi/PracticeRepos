package com.hexa.cozyhavenhotel.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.models.Admin;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.models.User;
import com.hexa.cozyhavenhotel.repositories.AdminRepository;
import com.hexa.cozyhavenhotel.repositories.GuestRepository;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;
import com.hexa.cozyhavenhotel.repositories.PaymentRepository;
import com.hexa.cozyhavenhotel.repositories.ReservationRepository;
import com.hexa.cozyhavenhotel.repositories.ReviewRepository;
import com.hexa.cozyhavenhotel.repositories.RoomRepository;
import com.hexa.cozyhavenhotel.repositories.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class AdminServiceImpl implements AdminService {

	private AdminRepository adminRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private GuestRepository guestRepository;
	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private ReservationRepository reservationRepository;
	@Autowired
	private HotelOwnerRepository hotelOwnerRepository;
	@Autowired
	private HotelRepository hotelRepository;
	@Autowired
	private RoomRepository roomRepository;
	
	  @Autowired
	    private ReviewRepository reviewRepository;
	@Autowired
	public AdminServiceImpl(AdminRepository adminRepository,UserRepository userRepository,GuestRepository guestRepository,
						PaymentRepository paymentRepository,
						ReservationRepository reservationRepository,
						HotelOwnerRepository hotelOwnerRepository,
						HotelRepository hotelRepository,
						RoomRepository roomRepository) {
		super();
		this.adminRepository = adminRepository;
		this.userRepository= userRepository;
		this.guestRepository =guestRepository;
		this. paymentRepository= paymentRepository;
		this. reservationRepository= reservationRepository;
		this. hotelOwnerRepository= hotelOwnerRepository;
		this.hotelRepository =hotelRepository;
		this.roomRepository=roomRepository;
		
	}
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Override
	public Admin createAdmin(AdminGuestOwnerDto adminGuestOwnerDto) {
		
		Admin admin=this.modelMapper.map(adminGuestOwnerDto, Admin.class);
		User user=this.modelMapper.map(adminGuestOwnerDto,User.class);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		admin.setUser(user);
		this.userRepository.save(user);
		return this.adminRepository.save(admin);

	}
	
	@Transactional
	public void deleteGuest(Long guestId) throws ResourceNotFoundException {
        Guest guest = guestRepository.findById(guestId)
            .orElseThrow(() -> new ResourceNotFoundException("Guest", "guestId", guestId));
        paymentRepository.deleteByGuestId(guestId);
        
        reservationRepository.deleteByGuestId(guestId);
        reviewRepository.deleteByGuestId(guestId);
        User user = guest.getUser();
        guestRepository.delete(guest);
        if (user != null) {
            userRepository.delete(user);
        }
	
	}
	

	@Transactional
	public void deleteHotelOwner(Long hotelOwnerId) throws ResourceNotFoundException {
	    HotelOwner hotelOwner = hotelOwnerRepository.findById(hotelOwnerId)
	            .orElseThrow(() -> new ResourceNotFoundException("hotelowner", "hotelOwnerId", hotelOwnerId));
	    Hotel hotel = hotelRepository.getByHotelOwnerId(hotelOwnerId);
	    if (hotel != null) {
	        List<Room> rooms = roomRepository.findByHotelId(hotel.getHotelId());

	        // Delete all Payments associated with Reservations for each Room
	        for (Room room : rooms) {
	            List<Reservation> reservations = reservationRepository.findByRoomId(room.getRoomId());
	            
	            for (Reservation reservation : reservations) {
	                // Delete the associated Payments first
	                paymentRepository.deleteReservationId(reservation.getReservationId());
	            }
	        }

	        // After deleting payments, delete Reservations
	        for (Room room : rooms) {
	            reservationRepository.deleteByRoomId(room.getRoomId());
	        }

	        // Delete Rooms associated with the Hotel
	        roomRepository.deleteByHotelId(hotel.getHotelId());

	        // Delete Reviews associated with the Hotel
	        reviewRepository.deleteByHotelId(hotel.getHotelId());

	        // Delete the Hotel
	        hotelRepository.deleteByHotelOwnerId(hotelOwnerId);
	    }

	    // Finally, delete the HotelOwner and associated User
	    hotelOwnerRepository.delete(hotelOwner);
	    User user = hotelOwner.getUser();
	    
	    if (user != null) {
	        userRepository.delete(user);
	    }
	}


}