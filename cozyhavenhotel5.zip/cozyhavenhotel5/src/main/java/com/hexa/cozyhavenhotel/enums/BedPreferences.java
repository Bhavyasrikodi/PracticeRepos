package com.hexa.cozyhavenhotel.enums;


public enum BedPreferences {
    SINGLE,
    DOUBLE,
    KING
}