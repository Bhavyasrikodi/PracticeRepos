package com.hexa.cozyhavenhotel.dtos;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class HotelOutputDto {
	
	private Long hotelId;
	private String hotelName;
    private String location;
    private Boolean isDining;
    private Boolean isParking;
    private Boolean isfreeWifi;
    private Boolean isRoomservice;
    private Boolean isswimmingPool;
    private Boolean isFitnessCenter;
    private String imageurl;
    private Double rating;
    private String hotelOwnerName;
  
    @Email
    private String email;

    private String phoneNumber;
   
    private String businessLicense;
    
    

	public HotelOutputDto(Long hotelId, String hotelName, String location, Boolean isDining, Boolean isParking,
			Boolean isfreeWifi, Boolean isRoomservice, Boolean isswimmingPool, Boolean isFitnessCenter, String imageurl,
			Double rating, String hotelOwnerName, @Email String email, String phoneNumber, String businessLicense) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.isDining = isDining;
		this.isParking = isParking;
		this.isfreeWifi = isfreeWifi;
		this.isRoomservice = isRoomservice;
		this.isswimmingPool = isswimmingPool;
		this.isFitnessCenter = isFitnessCenter;
		this.imageurl = imageurl;
		this.rating = rating;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.businessLicense = businessLicense;
	}

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Boolean getIsDining() {
		return isDining;
	}

	public void setIsDining(Boolean isDining) {
		this.isDining = isDining;
	}

	public Boolean getIsParking() {
		return isParking;
	}

	public void setIsParking(Boolean isParking) {
		this.isParking = isParking;
	}

	public Boolean getIsfreeWifi() {
		return isfreeWifi;
	}

	public void setIsfreeWifi(Boolean isfreeWifi) {
		this.isfreeWifi = isfreeWifi;
	}

	public Boolean getIsRoomservice() {
		return isRoomservice;
	}

	public void setIsRoomservice(Boolean isRoomservice) {
		this.isRoomservice = isRoomservice;
	}

	public Boolean getIsswimmingPool() {
		return isswimmingPool;
	}

	public void setIsswimmingPool(Boolean isswimmingPool) {
		this.isswimmingPool = isswimmingPool;
	}

	public Boolean getIsFitnessCenter() {
		return isFitnessCenter;
	}

	public void setIsFitnessCenter(Boolean isFitnessCenter) {
		this.isFitnessCenter = isFitnessCenter;
	}

	public String getHotelOwnerName() {
		return hotelOwnerName;
	}

	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getBusinessLicense() {
		return businessLicense;
	}

	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}



	public HotelOutputDto(Long hotelId, String hotelName, String location, Boolean isDining, Boolean isParking,
			Boolean isfreeWifi, Boolean isRoomservice, Boolean isswimmingPool, Boolean isFitnessCenter,
			String hotelOwnerName, @Email String email, String phoneNumber, String businessLicense) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.isDining = isDining;
		this.isParking = isParking;
		this.isfreeWifi = isfreeWifi;
		this.isRoomservice = isRoomservice;
		this.isswimmingPool = isswimmingPool;
		this.isFitnessCenter = isFitnessCenter;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.businessLicense = businessLicense;
	}

	public HotelOutputDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
