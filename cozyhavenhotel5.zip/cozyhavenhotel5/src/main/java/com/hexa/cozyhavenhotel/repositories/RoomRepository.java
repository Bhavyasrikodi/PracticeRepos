package com.hexa.cozyhavenhotel.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexa.cozyhavenhotel.models.Room;

import jakarta.transaction.Transactional;
@Repository
public interface RoomRepository extends JpaRepository<Room,Long>{

	@Modifying
	@Transactional
    @Query("DELETE FROM Room r WHERE r.hotel.id = :hotelId")
    void deleteByHotelId(@Param("hotelId") Long hotelId);
	
	 @Query("SELECT r FROM Room r WHERE r.hotel.id = :hotelId")
	    List<Room> findByHotelId(@Param("hotelId") Long hotelId);
	 
	 @Query("SELECT CASE WHEN COUNT(r) > 0 THEN false ELSE true END " +
	           "FROM Reservation r WHERE r.room.id = :roomId AND " +
	           "(r.startDate < :endDate AND r.endDate > :startDate)")
	    boolean isRoomAvailableForDateRange(@Param("roomId") Long roomId,
	                                        @Param("startDate") LocalDate startDate,
	                                        @Param("endDate") LocalDate endDate);
	 
	 @Query("SELECT r FROM Room r " +
		       "LEFT JOIN Reservation res ON res.room.id = r.id " +
		       "WHERE r.hotel.hotelId = :hotelId AND " +
		       "(res IS NULL OR (res.endDate <= :startDate OR res.startDate >= :endDate))")
		List<Room> findAvailableRoomsByHotelAndDates(
		        @Param("hotelId") Long hotelId, 
		        @Param("startDate") LocalDate startDate, 
		        @Param("endDate") LocalDate endDate);


}
