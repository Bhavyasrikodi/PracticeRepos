package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.BedPreferences;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;

public class RoomOutputDto {
	 private Long roomId;
	private String roomNumber;
    private Double baseFare;
    private Integer maxOccupancy;
    private Boolean isAc;
    
	private Boolean availability;

    @Enumerated(EnumType.STRING)
    private BedPreferences bedPreferences;
    private String hotelName;
    private String location;
    private String hotelOwnerName;
    
    @Email
    private String email;

    private String phoneNumber;
    private String roomimageurl;
    
    


	public String getRoomimageurl() {
		return roomimageurl;
	}

	public void setRoomimageurl(String roomimageurl) {
		this.roomimageurl = roomimageurl;
	}

	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Double getBaseFare() {
		return baseFare;
	}

	public void setBaseFare(Double baseFare) {
		this.baseFare = baseFare;
	}

	public Integer getMaxOccupancy() {
		return maxOccupancy;
	}

	public void setMaxOccupancy(Integer maxOccupancy) {
		this.maxOccupancy = maxOccupancy;
	}

	public Boolean getIsAc() {
		return isAc;
	}

	public void setIsAc(Boolean isAc) {
		this.isAc = isAc;
	}

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	public BedPreferences getBedPreferences() {
		return bedPreferences;
	}

	public void setBedPreferences(BedPreferences bedPreferences) {
		this.bedPreferences = bedPreferences;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getHotelOwnerName() {
		return hotelOwnerName;
	}

	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	public RoomOutputDto(Long roomId, String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc,
			Boolean availability, BedPreferences bedPreferences, String hotelName, String location,
			String hotelOwnerName, @Email String email, String phoneNumber) {
		super();
		this.roomId = roomId;
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		this.bedPreferences = bedPreferences;
		this.hotelName = hotelName;
		this.location = location;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}

	public RoomOutputDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoomOutputDto(Long roomId, String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc,
			Boolean availability, BedPreferences bedPreferences, String hotelName, String location,
			String hotelOwnerName, @Email String email, String phoneNumber, String roomimageurl) {
		super();
		this.roomId = roomId;
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		this.bedPreferences = bedPreferences;
		this.hotelName = hotelName;
		this.location = location;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.roomimageurl = roomimageurl;
	}
	
    
    
}
