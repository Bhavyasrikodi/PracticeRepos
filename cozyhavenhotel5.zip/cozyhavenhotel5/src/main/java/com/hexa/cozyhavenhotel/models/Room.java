package com.hexa.cozyhavenhotel.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hexa.cozyhavenhotel.enums.BedPreferences;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "rooms")
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roomId;

    private String roomNumber;
    private Double baseFare;
    private Integer maxOccupancy;
    private Boolean isAc;
    
	private Boolean availability;

    @Enumerated(EnumType.STRING)
    private BedPreferences bedPreferences;
    private String roomimageurl;
    public String getRoomimageurl() {
		return roomimageurl;
	}
	public void setRoomimageurl(String roomimageurl) {
		this.roomimageurl = roomimageurl;
	}
	@ManyToOne
    @JoinColumn(name = "hotel_id", referencedColumnName = "hotelId")
    @JsonBackReference
    private Hotel hotel;

    

    public Room(Long roomId, String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc,
			Boolean availability, BedPreferences bedPreferences, Hotel hotel) {
		super();
		this.roomId = roomId;
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		this.bedPreferences = bedPreferences;
		
		this.hotel = hotel;
		
	}
	public Room(Long roomId, String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc,
			Boolean availability,BedPreferences bedPreferences) {
		super();
		this.roomId = roomId;
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		
		this.bedPreferences = bedPreferences;
	}
	// Getters and Setters


	


	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Room(Long roomId,String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc, Boolean availability,
			BedPreferences bedPreferences, String roomimageurl) {
		super();
		this.roomId = roomId;
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		this.bedPreferences = bedPreferences;
		this.roomimageurl = roomimageurl;
		this.hotel = hotel;
	}
	public Long getRoomId() {
		return roomId;
	}
	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	
	public Boolean getAvailability() {
		return availability;
	}
	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}
	public BedPreferences getBedPreferences() {
		return bedPreferences;
	}

	public void setBedPreferences(BedPreferences bedPreferences) {
		this.bedPreferences = bedPreferences;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public Double getBaseFare() {
		return baseFare;
	}

	public void setBaseFare(Double baseFare) {
		this.baseFare = baseFare;
	}

	public Integer getMaxOccupancy() {
		return maxOccupancy;
	}

	public void setMaxOccupancy(Integer maxOccupancy) {
		this.maxOccupancy = maxOccupancy;
	}

	public Boolean getIsAc() {
		return isAc;
	}

	public void setIsAc(Boolean isAc) {
		this.isAc = isAc;
	}
	public Room(String roomNumber, Double baseFare, Integer maxOccupancy, Boolean isAc, Boolean availability,
			BedPreferences bedPreferences) {
		super();
		this.roomNumber = roomNumber;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.availability = availability;
		this.bedPreferences = bedPreferences;
	}

   
}
