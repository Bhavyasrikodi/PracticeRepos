package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.HotelDto;
import com.hexa.cozyhavenhotel.models.Hotel;
@Service
public interface HotelService {

	public Hotel createHotel(HotelDto hotelDto)throws ResourceNotFoundException;
	public Hotel getHotelById(long hotelId)throws ResourceNotFoundException;
	public List<Hotel> getHotelByLocation(String location)throws ResourceNotFoundException;
	//public List<Hotel> findHotelsByDates(LocalDate startDate, LocalDate endDate)throws ResourceNotFoundException;
	public List<Hotel> getAllHotels() ;
	public Hotel updateHotelOwner(Long hotelId,Long ownerId)throws ResourceNotFoundException ;
	public Hotel updateHotelByOwnerId(Long hotelId)throws ResourceNotFoundException;
	public List<Hotel> findHotelsByDates(String location,LocalDate startDate, LocalDate endDate)throws ResourceNotFoundException;
	//public List<Hotel> findHotelsWithRooms(Long hotelId,LocalDate startDate, LocalDate endDate)throws ResourceNotFoundException;
	//public Hotel getHotelByName(String hotelName)throws ResourceNotFoundException;
}
