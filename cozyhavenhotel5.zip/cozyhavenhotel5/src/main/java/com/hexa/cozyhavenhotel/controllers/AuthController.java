
  package com.hexa.cozyhavenhotel.controllers;
  
  import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired; 
  import org.springframework.security.authentication.AuthenticationManager; 
  import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; 
  import org.springframework.security.core.userdetails.UserDetails; 
  import org.springframework.security.crypto.password.PasswordEncoder; 
  import org.springframework.web.bind.annotation.CrossOrigin; 
  import org.springframework.web.bind.annotation.PostMapping; 
  import org.springframework.web.bind.annotation.RequestBody; 
  import org.springframework.web.bind.annotation.RequestMapping; 
  import org.springframework.web.bind.annotation.RestController;
  
  import com.hexa.cozyhavenhotel.JwtUtil; 
  import com.hexa.cozyhavenhotel.models.User; 
  import com.hexa.cozyhavenhotel.repositories.UserRepository; 
  import com.hexa.cozyhavenhotel.services.MyUserDetailsService;
  
  @RestController
  @CrossOrigin("http://localhost:3000")
  public class AuthController {
  
  @Autowired 
  private AuthenticationManager authenticationManager;
  
  @Autowired 
  private UserRepository userRepository;
  
  @Autowired 
  private PasswordEncoder passwordEncoder;
  
  @Autowired 
  private MyUserDetailsService userDetailsService;
  
  @Autowired 
  private JwtUtil jwtUtil;
  

  @PostMapping("/auth/token")
  public Map<String, String> createAuthenticationToken(@RequestBody User authenticationRequest) throws Exception {
      try {
          authenticationManager.authenticate(
                  new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
          );
      } catch (Exception e) {
          throw new Exception("Incorrect username or password", e);
      }

      final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
      final String jwt = jwtUtil.generateToken(userDetails.getUsername());
      User user = userRepository.getUserByUsername(authenticationRequest.getUsername());
      Map<String, String> response = new HashMap<>();
      response.put("token", jwt);
      response.put("username", userDetails.getUsername());
      response.put("role", user.getRole().name());

      return response;
  }}

  
  
  
  
  
  
  
  
  
  
  
  
  
  
 