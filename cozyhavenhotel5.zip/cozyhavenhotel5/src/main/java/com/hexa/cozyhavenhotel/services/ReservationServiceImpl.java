package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.customExceptions.RoomUnavailableException;
import com.hexa.cozyhavenhotel.dtos.ReservationDto;
import com.hexa.cozyhavenhotel.enums.PaymentStatus;
import com.hexa.cozyhavenhotel.enums.ReservationStatus;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.models.User;
import com.hexa.cozyhavenhotel.repositories.GuestRepository;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;
import com.hexa.cozyhavenhotel.repositories.PaymentRepository;
import com.hexa.cozyhavenhotel.repositories.ReservationRepository;
import com.hexa.cozyhavenhotel.repositories.RoomRepository;


@Service
public class ReservationServiceImpl implements ReservationService{
	@Autowired
	private ModelMapper modelMapper;
	private ReservationRepository reservationRepos;
	private GuestRepository guestRepos;
	private RoomRepository roomRepos;
	private GuestService guestService;
	private RoomService roomService;
	private HotelOwnerRepository hotelOwnerRepos;
	private HotelRepository hotelRepos;
	@Autowired
    private PaymentRepository paymentRepos;
	
	@Autowired
	public ReservationServiceImpl(ReservationRepository reservationRepos, GuestRepository guestRepos, GuestService guestService,
			RoomRepository roomRepos,RoomService roomService,PaymentRepository paymentRepos, 
			HotelOwnerRepository hotelOwnerRepos, HotelRepository hotelRepos) {
		super();
		this.reservationRepos = reservationRepos;
		this.guestRepos = guestRepos;
		this.guestService = guestService;
		this.roomRepos=roomRepos;
		this.roomService=roomService;
		this.paymentRepos=paymentRepos;
		this.hotelOwnerRepos=hotelOwnerRepos;
		this.hotelRepos =hotelRepos;
		
	}

	
	@Override
	public Reservation doReservation(Long guestId,Long roomId,double calculateTotalFare, ReservationDto reservationDto)throws ResourceNotFoundException {
		
		Guest guest=guestService.getGuestById(guestId);
		Room room=roomService.getRoomById(roomId);
		Reservation reservation=this.modelMapper.map(reservationDto,Reservation.class);
		reservation.setTotalPrice(calculateTotalFare);
		reservation.setGuest(guest);
		reservation.setRoom(room);
		return this.reservationRepos.save(reservation);
	}
	
	@Override
	public Reservation getReservationById(Long reservationId)throws ResourceNotFoundException{
		Reservation reservation=this.reservationRepos.findById(reservationId).orElseThrow(()->new ResourceNotFoundException("reservation","id",reservationId));
		return reservation;
	}
	
	@Override
	public List<Reservation> getReservationByGuestId(Long guestId)throws ResourceNotFoundException{
		List<Reservation> reservations = this.reservationRepos.getReservationByGuest(guestId);
		return reservations;
	}

    
    public Reservation cancelReservationAndRequestRefund(Long reservationId) throws ResourceNotFoundException {
    	 Reservation reservation = reservationRepos.findById(reservationId)
    	            .orElseThrow(() -> new ResourceNotFoundException("Reservation","reservationId" , reservationId));
    	        if (reservation.getReservationStatus() == ReservationStatus.CANCELLED) {
    	            throw new IllegalStateException("Reservation is already canceled.");
    	        }
    	        reservation.setReservationStatus(ReservationStatus.CANCELLED);
    	        List<Payment> payments = paymentRepos.findByReservationId(reservationId);
    	        for (Payment payment : payments) {
    	            if (payment.getPaymentStatus() == PaymentStatus.PAID) {
    	                payment.setPaymentStatus(PaymentStatus.PENDING_REFUND);
    	                paymentRepos.save(payment);  
    	            }
    	        }
    	        
        return reservationRepos.save(reservation);
    }
    
    public Payment processRefund(Long paymentId) throws ResourceNotFoundException {
        Payment payment = paymentRepos.findById(paymentId)
            .orElseThrow(() -> new ResourceNotFoundException("Payment ","paymentId" , paymentId));

        if (payment.getPaymentStatus() != PaymentStatus.PENDING_REFUND) {
            throw new IllegalStateException("Refund is not pending for this payment.");
        }

        payment.setPaymentStatus(PaymentStatus.REFUNDED);
        return paymentRepos.save(payment);
    }

		
	@Override
    public List<Reservation> getReservationsByHotelOwner(Long hotelOwnerId) throws ResourceNotFoundException {
     
        List<Hotel> hotels = this.hotelRepos.findByHotelOwnerId(hotelOwnerId);
        
        if (hotels.isEmpty()) {
            throw new ResourceNotFoundException("HotelOwner","hotelOwnerId", hotelOwnerId);
        }
        List<Reservation> reservations = reservationRepos.findByHotels(hotels);
        for(Reservation reservation:reservations) {
        	Guest guest=reservation.getGuest();
        	User user1=guest.getUser();
			Room room=reservation.getRoom();
			Hotel hotel=room.getHotel();
			 HotelOwner hotelOwner = hotel.getHotelOwner();
		     User user = hotelOwner.getUser();
		}
        
        return reservations;
    }


	@Override
	public Reservation reserveRoom(Long guestId, Long roomId, int numberOfPersons, int numberOfAdults,
	        int numberOfChildren, int numberOfRooms, LocalDate startDate, LocalDate endDate, ReservationDto reservationDto)
	        throws ResourceNotFoundException {

	    Room room = roomRepos.findById(roomId)
	            .orElseThrow(() -> new ResourceNotFoundException("Room", "roomId", roomId));

	    if (!roomRepos.isRoomAvailableForDateRange(roomId, startDate, endDate)) {
	        throw new IllegalArgumentException("Room is not available for the selected dates.");
	    }
	    Guest guest = guestService.getGuestById(guestId);
	    int durationOfStay = (int) ChronoUnit.DAYS.between(startDate, endDate);
	    if (durationOfStay <= 0) {
	        throw new IllegalArgumentException("The stay duration must be at least 1 day.");
    }
	    double amount = calculateChargeForOneDay(roomId,numberOfPersons,numberOfAdults,numberOfChildren);
	    
	    double totalBaseFare = room.getBaseFare() * numberOfRooms * durationOfStay;
	    Reservation reservation = modelMapper.map(reservationDto, Reservation.class);
	    reservation.setStartDate(startDate);
	    reservation.setEndDate(endDate);
	    reservation.setNumberOfPersons(numberOfPersons);
	    reservation.setTotalPrice(amount);
	    reservation.setGuest(guest);
	    reservation.setRoom(room);

	    Reservation savedReservation = reservationRepos.save(reservation);

	    room.setAvailability(false);  
	    roomRepos.save(room);

	    return savedReservation;
	}

	   public double calculateChargeForOneDay(Long roomId,int numberOfPeople,int numberOfAdults,int numberOfChildren) throws ResourceNotFoundException {
		   Room room = roomRepos.findById(roomId)
		            .orElseThrow(() -> new ResourceNotFoundException("Room", "roomId", roomId));
		   double amount=0;
		   if(room.getMaxOccupancy()==2) {
		    	if(numberOfPeople==2) {
		    		if(numberOfAdults==2) {
		    			 amount=room.getBaseFare()+(room.getBaseFare()*0.4);
		    		}
		    		if(numberOfChildren==2) {
		    			 amount=room.getBaseFare()+(room.getBaseFare()*0.2);
		    		}
		    		else {
		    			 amount=room.getBaseFare()+(room.getBaseFare()*0.2);
		    		}
		    	}
		    	else {
		    		 amount=room.getBaseFare();
		    	}
		    	
		    }
		    
		    
		    if(room.getMaxOccupancy()==4) {
		    	if(numberOfPeople>2) {
		    	if(numberOfPeople==3) {
		    		if(numberOfAdults==3) {
		    			 amount=room.getBaseFare()+(room.getBaseFare()*0.4);
		    		}
		    		else {
		    			 amount=room.getBaseFare()+(room.getBaseFare()*0.2);
		    		}
		    	}
		    	else {
		    		 if(numberOfAdults==4) {
		    			  amount=room.getBaseFare()+((room.getBaseFare()*0.4)*2);
		    		 }
		    		 if(numberOfAdults==3) {
		    			  amount=room.getBaseFare()+(room.getBaseFare()*0.4)+(room.getBaseFare()*0.2);
		    		 }
		    		 else {
		    			  amount=room.getBaseFare()+((room.getBaseFare()*0.2)*2);
		    		 }
		    	}
		    }
		    	else {
		    		 amount=room.getBaseFare();
		    	}
		    	
		  }
		    
		    
		  if(room.getMaxOccupancy()==6) {
			  if(numberOfPeople>4) {
				  if(numberOfPeople==5) {
					  if(numberOfAdults==5) {
						   amount=room.getBaseFare()+(room.getBaseFare()*0.4);
					  }
					  else {
						  amount=room.getBaseFare()+(room.getBaseFare()*0.2);
					  }
				  }
				  else {
					  if(numberOfAdults==6) {
						  amount=room.getBaseFare()+((room.getBaseFare()*0.4)*2);
					  }
					  else if(numberOfAdults==5) {
						   amount=room.getBaseFare()+(room.getBaseFare()*0.4)+(room.getBaseFare()*0.2);
					  }
					  else {
						   amount=room.getBaseFare()+((room.getBaseFare()*0.2)*2);
					  }
				  }
			  }
			  else {
				  amount=room.getBaseFare();
			  }
			  
			 
		  }
		  return amount;
	   }
	   
	   
	// Check if the room is available for a specific date range
	private boolean isRoomAvailable(Room room, LocalDate startDate, LocalDate endDate) {
	    // You can implement this using your repository, possibly a query method
	    return roomRepos.isRoomAvailableForDateRange(room.getRoomId(), startDate, endDate);
	}
	
	public List<Reservation> getAllReservations() {
		return this.reservationRepos.findAll();
		
	}
	
	public Reservation reservesRoom(Long guestId,Long roomId,ReservationDto reservationDto)throws ResourceNotFoundException{
		
		Room room = roomRepos.findById(roomId)
	            .orElseThrow(() -> new ResourceNotFoundException("Room", "roomId", roomId));
	    Guest guest = guestService.getGuestById(guestId);
	    Reservation reservation=this.modelMapper.map(reservationDto,Reservation.class);
	    LocalDate startDate=reservation.getStartDate();
	    LocalDate endDate=reservation.getEndDate();
	    Integer numberOfPersons=reservation.getNumberOfPersons();
	    Integer numberOfAdults=reservation.getNumberOfAdults();
	    Integer numberOfChildren=reservation.getNumberOfChildren();
	    Integer numberOfRooms=reservation.getNumberOfRooms();
	    if (!roomRepos.isRoomAvailableForDateRange(roomId, startDate, endDate)) {
	        throw new RoomUnavailableException("Room is not available for the selected dates.");
	    }
	    int durationOfStay = (int) ChronoUnit.DAYS.between(startDate, endDate);
	    if (durationOfStay <= 0) {
	        throw new IllegalArgumentException("The stay duration must be at least 1 day.");
    }
	    
	    double totalBaseFare = room.getBaseFare() * numberOfRooms * durationOfStay;
	    double amount = calculateChargeForOneDay(roomId,numberOfPersons,numberOfAdults,numberOfChildren)+totalBaseFare;
	    reservation.setStartDate(startDate);
	    reservation.setEndDate(endDate);
	    reservation.setNumberOfPersons(numberOfPersons);
	    reservation.setTotalPrice(amount);
	    reservation.setGuest(guest);
	    reservation.setRoom(room);
	    reservation.setReservationStatus(ReservationStatus.BOOKED);
	    Reservation savedReservation = reservationRepos.save(reservation);

	    room.setAvailability(false);  
	    roomRepos.save(room);

	    return savedReservation;
	}
	
	
	
}
	
	