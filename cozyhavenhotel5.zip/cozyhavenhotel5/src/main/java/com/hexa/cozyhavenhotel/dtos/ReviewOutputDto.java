package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

public class ReviewOutputDto {
	
	  private Long reviewId;
	
	private Double rating;  // Rating from 1 to 5
    private String reviewText;
    private LocalDate reviewDate;
    private String hotelName;
    private String location;
    private String hotelOwnerName;
    private String guestName;
    private String phoneNumber;
    
    
	public Long getReviewId() {
		return reviewId;
	}

	public void setReviewId(Long reviewId) {
		this.reviewId = reviewId;
	}

	public Double getRating() {
		return rating;
	}
	
	public void setRating(Double rating) {
		this.rating = rating;
	}
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	public LocalDate getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(LocalDate reviewDate) {
		this.reviewDate = reviewDate;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getHotelOwnerName() {
		return hotelOwnerName;
	}
	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public ReviewOutputDto(Long reviewId, Double rating, String reviewText, LocalDate reviewDate, String hotelName,
			String location, String hotelOwnerName, String guestName, String phoneNumber) {
		super();
		this.reviewId = reviewId;
		this.rating = rating;
		this.reviewText = reviewText;
		this.reviewDate = reviewDate;
		this.hotelName = hotelName;
		this.location = location;
		this.hotelOwnerName = hotelOwnerName;
		this.guestName = guestName;
		this.phoneNumber = phoneNumber;
	}

	public ReviewOutputDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
