package com.hexa.cozyhavenhotel.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.dtos.GuestUserDto;

import com.hexa.cozyhavenhotel.models.Guest;
@Service
public interface GuestService {
	public Guest createGuest(AdminGuestOwnerDto adminGuestOwnerDto) ;
	public Guest getGuestById(Long guestId)throws ResourceNotFoundException;
	//public void deleteGuest(Long guestId) throws ResourceNotFoundException ;
	public List<Guest> getAllGuests();
	public Long getGuestId(String username);
}
