package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.Role;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class AdminDto {
	
	private Long adminId;
    @NotNull
	@Size(min = 2, max = 50)
    private String adminName;
    @NotNull
    @Email
    private String email;
  @NotNull
    private String phoneNumber;
    @NotNull
    private String adminLevel;
    @Enumerated(EnumType.STRING)
	private Role role;
    
    
	public Long getAdminId() {
		return adminId;
	}
	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAdminLevel() {
		return adminLevel;
	}
	public void setAdminLevel(String adminLevel) {
		this.adminLevel = adminLevel;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	
	public AdminDto(Long adminId, @NotNull @Size(min = 2, max = 50) String adminName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull String adminLevel, Role role) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.adminLevel = adminLevel;
		this.role = role;
	}
	public AdminDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
