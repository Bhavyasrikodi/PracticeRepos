package com.hexa.cozyhavenhotel.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.ReviewDto;
import com.hexa.cozyhavenhotel.dtos.ReviewOutputDto;
import com.hexa.cozyhavenhotel.models.Review;
import com.hexa.cozyhavenhotel.services.ReviewService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/review")
@CrossOrigin("http://localhost:3000")
public class ReviewController {

	private final ReviewService reviewService;
	private final ModelMapper modelMapper;
	@Autowired
	public ReviewController(ReviewService reviewService,ModelMapper modelMapper) {
		this.reviewService=reviewService;
		this.modelMapper = new ModelMapper();
	}
	
	@PreAuthorize("hasRole('GUEST')")
	@PostMapping("/giveReview")
	public ResponseEntity<ReviewOutputDto> rateNow(@Valid @RequestBody ReviewDto reviewDto,@RequestParam Long guestId,@RequestParam Long hotelId) throws ResourceNotFoundException {
		Review review=this.reviewService.rateNow(reviewDto, guestId, hotelId);
		ReviewOutputDto reviewOutputdto=this.modelMapper.map(review, ReviewOutputDto.class);
		reviewOutputdto.setHotelName(review.getHotel().getHotelName());
		reviewOutputdto.setLocation(review.getHotel().getLocation());
		reviewOutputdto.setHotelOwnerName(review.getHotel().getHotelOwner().getHotelOwnerName());
		reviewOutputdto.setGuestName(review.getGuest().getGuestName());
		reviewOutputdto.setPhoneNumber(review.getGuest().getPhoneNumber());
		return ResponseEntity.ok(reviewOutputdto);
}
}











