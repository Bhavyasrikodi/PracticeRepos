package com.hexa.cozyhavenhotel.services;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.dtos.ReservationDto;
import com.hexa.cozyhavenhotel.dtos.ReservationOutputDto;
import com.hexa.cozyhavenhotel.enums.BedPreferences;
import com.hexa.cozyhavenhotel.enums.ReservationStatus;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Review;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.models.User;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.UserRepository;
@Service
public class HotelOwnerServiceImpl implements HotelOwnerService{
	
	private HotelOwnerRepository hotelOwnerRepos;
	private UserRepository userRepository;
	
	@Autowired
	public HotelOwnerServiceImpl(HotelOwnerRepository hotelOwnerRepos, UserRepository userRepository) {
		super();
		this.hotelOwnerRepos = hotelOwnerRepos;
		this.userRepository = userRepository;
		
	}
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Override
	public HotelOwner createOwner(AdminGuestOwnerDto adminGuestOwnerDto) {
		HotelOwner hotelOwner=this.modelMapper.map(adminGuestOwnerDto,HotelOwner.class);
		User user=this.modelMapper.map(adminGuestOwnerDto, User.class);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		hotelOwner.setUser(user);
		this.userRepository.save(user);
		return this.hotelOwnerRepos.save(hotelOwner);
		
		
	}
	
	public HotelOwner getOwnerById(Long ownerId)throws ResourceNotFoundException {
		HotelOwner hotelOwner=this.hotelOwnerRepos.findById(ownerId).orElseThrow(()->new ResourceNotFoundException("hotelOwner","id",ownerId));
		return hotelOwner;
	}
	
	public List<HotelOwner> getAllOwners(){
		List<HotelOwner>owners=hotelOwnerRepos.findAll(); 
		return owners;
	}
	
	
	@Override
	public List<ReservationOutputDto> getReservationsOfHotel(Long hotelId) {
	    List<Object[]> rawResults = this.hotelOwnerRepos.getRawReservationsOfHotel(hotelId);
	    List<ReservationOutputDto> reservations = new ArrayList<>();
	    
	    for (Object[] row : rawResults) {
	        ReservationOutputDto dto = new ReservationOutputDto(
	            (Long) row[7], // roomId
	            (Long) row[8], // guestId
	            (Long) row[0], // reservationId
	            ((java.sql.Date) row[1]).toLocalDate(), // startDate
	            ((java.sql.Date) row[2]).toLocalDate(), // endDate
	            (Integer) row[3], // numberOfPersons
	            (Integer) row[4], // numberOfRooms
	            ReservationStatus.valueOf((String) row[5]), // reservationStatus
	            (Double) row[6]  // totalPrice
	        );
	        reservations.add(dto);
	    }
	return reservations;
  }

	@Override
	public List<Guest> getGuestsOfHotel(Long hotelId) {
		//return this.hotelOwnerRepos.getRawGuestsOfHotel(id);
	
		 List<Object[]> rawResults = this.hotelOwnerRepos.getRawGuestsOfHotel(hotelId);
		    List<Guest> guests = new ArrayList<>();
		    
		    for (Object[] row : rawResults) {
		        Guest guest = new Guest(
		            (Long) row[0], // GuestId
		            (String) row[5],//Guest Name
		            (String) row[2], // Email
		            (String) row[6], // Guest PhoneNumber
		            (String) row[3], //Gender
		            (String) row[1], // Aadhar Number
		            
		     
		            (String) row[4] // Guest address
		            
		             
		        );
		        guests.add(guest);
		    }
		return guests;
	}

	@Override
	public List<Room> getRoomsOfHotel(Long hotelId) {
		 List<Object[]> rawResults = this.hotelOwnerRepos.getRawRoomsOfHotel(hotelId);
		    List<Room> rooms = new ArrayList<>();
		    
		    for (Object[] row : rawResults) {
		        Room room = new Room(
		            (Long) row[0], // RoomId
		            (String) row[6],//Room number
		            (Double) row[2], // BaseFare
		            (Integer) row[5], // Max occupancy
		            (Boolean) row[4], // Is ac
		            (Boolean) row[1], // Availability
		           // ((BedPreferences) row[3]) //Bed Preferences
		            
		            BedPreferences.valueOf((String) row[3])
		        );
		        rooms.add(room);
		    }
		return rooms;
	}
	
	@Override
	public Long getHotelId(String username) {
		return this.hotelOwnerRepos.getHotelId(username);
	}


	 public List<Object[]> getPendingRequestPaymentsByHotelId(Long hotelId) {
	        return hotelOwnerRepos.findPendingRequestPaymentsByHotelId(hotelId);
	        }

	@Override
	public String findUsernameById(Long guestId) {
		return hotelOwnerRepos.getUsernameById(guestId);
	}

	@Override
	public Long getOwnerid(String username) {
		
		return this.hotelOwnerRepos.getOwnerId(username);
	}
	@Override
	public List<Object[]> getHotelReviews(Long hotelId){
		return this.hotelOwnerRepos.getReviewsOfHotel(hotelId);
	}
}
