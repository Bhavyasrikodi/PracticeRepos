package com.hexa.cozyhavenhotel.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.HotelOwner;

import jakarta.transaction.Transactional;



public interface HotelRepository extends JpaRepository<Hotel,Long>{
//	@Query("SELECT p FROM Product p WHERE p.name LIKE CONCAT('%',:productName,'%')"+
//			"OR p.description LIKE CONCAT('%',:productName,'%')") 
//	List<Product>searchProductsHQL(String productName);
	@Query("SELECT h FROM Hotel h WHERE h.location LIKE CONCAT('%',:location,'%')")
	List<Hotel> searchHotelsbylocation(String location);
	
	 @Query("SELECT h FROM Hotel h WHERE h.hotelOwner.id = :hotelOwnerId")
	    List<Hotel> findByHotelOwnerId(@Param("hotelOwnerId") Long hotelOwnerId);
	 
	 @Query("SELECT h FROM Hotel h WHERE h.hotelOwner.id = :hotelOwnerId")
	    Hotel getByHotelOwnerId(@Param("hotelOwnerId") Long hotelOwnerId);
	 
	
	 @Query("SELECT h FROM Hotel h WHERE h.hotelName LIKE CONCAT('%',:hotelName,'%')")
		Hotel searchHotelbyName(String hotelName);
		

//	   @Query("SELECT DISTINCT r.hotel FROM Room r " +
//	           "LEFT JOIN Reservation res ON res.room.id = r.id " +
//	           "WHERE res IS NULL OR (res.endDate <= :startDate OR res.startDate >= :endDate)")
//	    List<Hotel> findHotelsWithAvailableRooms(@Param("startDate") LocalDate startDate, 
//	                                             @Param("endDate") LocalDate endDate);
	 
	 @Query("SELECT DISTINCT r.hotel FROM Room r " +
		       "LEFT JOIN Reservation res ON res.room.id = r.id " +
		       "WHERE r.hotel.location = :location OR r.hotel.hotelName=:location AND " +
		       "(res IS NULL OR (res.endDate <= :startDate OR res.startDate >= :endDate))")
		List<Hotel> findHotelsWithAvailableRooms(
		        @Param("location") String location,
		        @Param("startDate") LocalDate startDate, 
		        @Param("endDate") LocalDate endDate);

	 
	 @Modifying
	    @Transactional
	    @Query("DELETE FROM Hotel h WHERE h.hotelOwner.id = :hotelOwnerId")
	    void deleteByHotelOwnerId(Long hotelOwnerId);
	 
	 Hotel findByHotelOwner(HotelOwner hotelOwner);

	 @Query("SELECT DISTINCT r.hotel FROM Room r " +
		       "LEFT JOIN Reservation res ON res.room.id = r.id " +
		       "WHERE r.hotel.hotelId = :hotelId AND " + 
		       "(res IS NULL OR (res.endDate <= :startDate OR res.startDate >= :endDate))")
		List<Hotel> getHotelsWithAvailableRooms(
		        @Param("hotelId") long hotelId, 
		        @Param("startDate") LocalDate startDate, 
		        @Param("endDate") LocalDate endDate);

	
}
