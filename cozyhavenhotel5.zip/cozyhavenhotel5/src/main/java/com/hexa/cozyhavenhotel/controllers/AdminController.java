package com.hexa.cozyhavenhotel.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.services.AdminService;
import com.hexa.cozyhavenhotel.services.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/admin")
@CrossOrigin("http://localhost:3000")
public class AdminController {
	private final AdminService adminService;
	private UserService userService;

	private final  ModelMapper modelMapper;
	@Autowired
	public AdminController(AdminService adminService, ModelMapper modelMapper) {
		super();
		this.adminService = adminService;
		this.modelMapper =modelMapper;
	}
	

	@PreAuthorize("hasRole('ADMIN')")
	 @DeleteMapping("/guests")
	    public ResponseEntity<String> deleteGuest(@Valid @RequestParam Long guestId) throws ResourceNotFoundException {
	        adminService.deleteGuest(guestId);
	        //return ResponseEntity.noContent().build();
	        return ResponseEntity.ok("guest with "+guestId+" was successfully deleted");
	    }
	@PreAuthorize("hasRole('ADMIN')")
	 @DeleteMapping("/hotelOwner")
	    public ResponseEntity<String> deleteHotelOwner(@Valid @RequestParam Long hotelOwnerId) throws ResourceNotFoundException {
	        adminService.deleteHotelOwner(hotelOwnerId);
	        //return ResponseEntity.noContent().build();
	        return ResponseEntity.ok("hotelowner with "+hotelOwnerId+" was successfully deleted");
	    }
	

}
