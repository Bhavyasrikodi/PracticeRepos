package com.hexa.cozyhavenhotel.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.models.Room;

import jakarta.transaction.Transactional;
@Repository
public interface ReservationRepository extends JpaRepository<Reservation,Long>{
	
	@Query("SELECT r FROM Reservation r " +
		       "LEFT JOIN r.guest g " +
		       "WHERE r.guest.id = :guestId")
		List<Reservation> getReservationByGuest(@Param("guestId") Long guestId);
	
//	@Query("SELECT r FROM Reservation r WHERE r.room.hotel = :hotel")
//    List<Reservation> findByHotel(@Param("hotel") Hotel hotel);
	
	 @Query("SELECT r FROM Reservation r WHERE r.room.hotel IN :hotels")
	    List<Reservation> findByHotels(@Param("hotels") List<Hotel> hotels);
	 @Modifying
		@Transactional
	    @Query("DELETE FROM Reservation r WHERE r.guest.id = :guestId")
	    void deleteByGuestId(@Param("guestId") Long guestId);

	 @Modifying
	 @Transactional
	    @Query("DELETE FROM Reservation r WHERE r.room.id = :roomId")
	    void deleteByRoomId(@Param("roomId") Long roomId);
	 
	 @Query("SELECT r FROM Room r WHERE r.hotel.id = :hotelId")
	    List<Room> findByHotelId(@Param("hotelId") Long hotelId);
	 
	 @Query("SELECT r FROM Reservation r WHERE r.room.id = :roomId")
	    List<Reservation> findByRoomId(@Param("roomId") Long roomId);
	 
	 
}
