package com.hexa.cozyhavenhotel.models;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.PaymentStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    @OneToOne
    @JoinColumn(name = "reservation_id", referencedColumnName = "reservationId")
    private Reservation reservation;

    private Double amount;
    private LocalDate paymentDate;

    @ManyToOne
    @JoinColumn(name="guest_id",referencedColumnName="guestId")
    private Guest guest;
    
    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

	public Payment(Long paymentId, Reservation reservation, Double amount, LocalDate paymentDate,
			PaymentStatus paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.reservation = reservation;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public Guest getGuest() {
		return guest;
	}

	public void setGuest(Guest guest) {
		this.guest = guest;
	}

	public Payment(Long paymentId, Reservation reservation, Double amount, LocalDate paymentDate, Guest guest,
			PaymentStatus paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.reservation = reservation;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.guest = guest;
		this.paymentStatus = paymentStatus;
	}

    // Getters and Setters
}


