package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.PaymentStatus;
import com.hexa.cozyhavenhotel.models.Reservation;

public class PaymentDto {

	private ReservationDto reservationDto;
	
	private Long paymentId;
    private Double amount;
    private LocalDate paymentDate;
    private PaymentStatus paymentStatus;
    private GuestDto guestDto;
    
    
	
	public PaymentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public PaymentDto(Long paymentId, Double amount, LocalDate paymentDate, PaymentStatus paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}



	public Long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	public ReservationDto getReservationDto() {
		return reservationDto;
	}
	public void setReservationDto(ReservationDto reservationDto) {
		this.reservationDto = reservationDto;
	}
	public GuestDto getGuestDto() {
		return guestDto;
	}
	public void setGuestDto(GuestDto guestDto) {
		this.guestDto = guestDto;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDate getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
}
