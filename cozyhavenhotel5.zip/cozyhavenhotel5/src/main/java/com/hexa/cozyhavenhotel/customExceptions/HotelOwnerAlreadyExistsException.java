package com.hexa.cozyhavenhotel.customExceptions;

public class HotelOwnerAlreadyExistsException extends RuntimeException {
    public HotelOwnerAlreadyExistsException(String message) {
        super(message);
    }

}
