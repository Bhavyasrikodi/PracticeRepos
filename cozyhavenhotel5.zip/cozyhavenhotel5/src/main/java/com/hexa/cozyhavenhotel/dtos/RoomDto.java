package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.BedPreferences;


import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;


public class RoomDto {
	private String roomNumber;
	 private Long roomId;
    private Boolean availability;
    private Double baseFare;
    private Integer maxOccupancy;
    private Boolean isAc;
   
    @Enumerated(EnumType.STRING)
    private BedPreferences bedPreferences;
    private String roomimageurl;
    
	private HotelDto hotelDto;

   

	public RoomDto(String roomNumber, Long roomId, Boolean availability, Double baseFare, Integer maxOccupancy,
			Boolean isAc, BedPreferences bedPreferences, HotelDto hotelDto) {
		super();
		this.roomNumber = roomNumber;
		this.roomId = roomId;
		this.availability = availability;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.bedPreferences = bedPreferences;
		this.hotelDto = hotelDto;
	}



	public RoomDto(String roomNumber,  Boolean availability, Double baseFare, Integer maxOccupancy,
			Boolean isAc, BedPreferences bedPreferences,HotelDto hotelDto) {
		super();
		this.roomNumber = roomNumber;
		
		this.availability = availability;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		
		this.bedPreferences = bedPreferences;
		this.hotelDto = hotelDto;
		
	}

	
	public RoomDto(String roomNumber, Boolean availability, Double baseFare, Integer maxOccupancy, Boolean isAc,
			BedPreferences bedPreferences, String roomimageurl, HotelDto hotelDto) {
		super();
		this.roomNumber = roomNumber;
		this.availability = availability;
		this.baseFare = baseFare;
		this.maxOccupancy = maxOccupancy;
		this.isAc = isAc;
		this.bedPreferences = bedPreferences;
		this.roomimageurl = roomimageurl;
		this.hotelDto = hotelDto;
	}



	public String getRoomimageurl() {
		return roomimageurl;
	}



	public void setRoomimageurl(String roomimageurl) {
		this.roomimageurl = roomimageurl;
	}

	public Long getRoomId() {
		return roomId;
	}



	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}



	public Double getBaseFare() {
		return baseFare;
	}

	public void setBaseFare(Double baseFare) {
		this.baseFare = baseFare;
	}

	public Integer getMaxOccupancy() {
		return maxOccupancy;
	}

	public void setMaxOccupancy(Integer maxOccupancy) {
		this.maxOccupancy = maxOccupancy;
	}

	public Boolean getIsAc() {
		return isAc;
	}

	public void setIsAc(Boolean isAc) {
		this.isAc = isAc;
	}

	public RoomDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	public BedPreferences getBedPreferences() {
		return bedPreferences;
	}

	public void setBedPreferences(BedPreferences bedPreferences) {
		this.bedPreferences = bedPreferences;
	}

	public HotelDto getHotelDto() {
		return hotelDto;
	}

	public void setHotelDto(HotelDto hotelDto) {
		this.hotelDto = hotelDto;
	}
    
}
