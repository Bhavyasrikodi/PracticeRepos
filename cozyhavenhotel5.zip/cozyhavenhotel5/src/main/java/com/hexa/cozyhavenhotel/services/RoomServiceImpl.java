package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.RoomDto;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;
import com.hexa.cozyhavenhotel.repositories.PaymentRepository;
import com.hexa.cozyhavenhotel.repositories.ReservationRepository;
import com.hexa.cozyhavenhotel.repositories.RoomRepository;

import jakarta.transaction.Transactional;

@Service
public class RoomServiceImpl implements RoomService {
	@Autowired 
	private ModelMapper modelMapper;
	private RoomRepository roomRepos;
	private HotelRepository hotelRepos;
	private HotelService hotelService;
	
	private HotelOwnerService hotelOwnerService;
	private HotelOwnerRepository hotelOwnerRepos;
	private ReservationRepository reservationRepos;
	private PaymentRepository paymentRepos;
	
	@Autowired
	public RoomServiceImpl(RoomRepository roomRepos, HotelRepository hotelRepos, HotelService hotelService,HotelOwnerRepository hotelOwnerRepos, HotelOwnerService hotelOwnerService, ReservationRepository reservationRepos,PaymentRepository paymentRepos) {
		super();
		this.roomRepos = roomRepos;
		this.hotelRepos = hotelRepos;
		this.hotelService = hotelService;
		this.hotelOwnerService=hotelOwnerService;
		this.hotelOwnerRepos=hotelOwnerRepos;
		this.reservationRepos=reservationRepos;
		this.paymentRepos=paymentRepos;
	}
	@Override
	public Room creatRoom(Long hotelId,RoomDto RoomDto)throws ResourceNotFoundException{
		
		Hotel hotel=hotelService.getHotelById(hotelId);
		Room room=this.modelMapper.map(RoomDto, Room.class);
		room.setHotel(hotel);
		return roomRepos.save(room);
	}
	@Override
	public List<Room> creatMultipleRoom(Long hotelId, List<RoomDto> listOfRoomdtos) throws ResourceNotFoundException {
		Hotel hotel=hotelService.getHotelById(hotelId);
		List<Room> listOfRooms=new ArrayList<>();
		for(RoomDto roomsDto:listOfRoomdtos) {
			Room room=this.modelMapper.map(roomsDto, Room.class);
			room.setHotel(hotel);
			listOfRooms.add(room);	
			
		}
	return roomRepos.saveAll(listOfRooms);
	}

	
	@Override
	public Room getRoomById(Long roomId)throws ResourceNotFoundException{
		Room room=this.roomRepos.findById(roomId).orElseThrow(()->new ResourceNotFoundException("room","id",roomId));
		return room;
	}
	
	@Override
	public Room addRoom(Long hotelOwnerId,Long hotelId,RoomDto RoomDto)throws ResourceNotFoundException{
		Room room=this.modelMapper.map(RoomDto, Room.class);
		Hotel hotel=hotelService.getHotelById(hotelId);
		HotelOwner hotelOwner=hotelOwnerService.getOwnerById(hotelOwnerId);
		room.setHotel(hotel);
		return roomRepos.save(room);
		
		}
	@Override
	public Room editRoom(Long roomId, RoomDto roomDto) throws ResourceNotFoundException {
		
		Room room = roomRepos.findById(roomId) .orElseThrow(() -> new ResourceNotFoundException("Room ","roomId", roomId));
		//Room room=this.modelMapper.map(roomDto, Room.class);
        room.setRoomNumber(roomDto.getRoomNumber());
        room.setAvailability(roomDto.getAvailability());
        room.setMaxOccupancy(roomDto.getMaxOccupancy());
        room.setBaseFare(roomDto.getBaseFare());
        room.setIsAc(roomDto.getIsAc());
        room.setBedPreferences(roomDto.getBedPreferences());
        return roomRepos.save(room);
    }
	@Override
	@Transactional
	public void removeRoom(Long roomId) throws ResourceNotFoundException {
        Room room = roomRepos.findById(roomId)
            .orElseThrow(() -> new ResourceNotFoundException("Room ","roomId", roomId));
        
        paymentRepos.deleteByReservationId(roomId);;
       reservationRepos.deleteByRoomId(roomId);
        roomRepos.delete(room);
        }
	

	@Override
	public List<Room> getRoomsByHotelId(Long hotelId)throws ResourceNotFoundException{
		List<Room> rooms=roomRepos.findByHotelId(hotelId);
		return rooms;
	}

	
	@Override
	public Map<Hotel, List<Room>> findAvailableRoomsForHotelsInLocation(
	        String location, LocalDate startDate, LocalDate endDate) throws ResourceNotFoundException {

	    // Get the list of hotels in the location with available rooms for the given date range
	    List<Hotel> hotels = this.hotelRepos.findHotelsWithAvailableRooms(location, startDate, endDate);

	    // If no hotels found, throw an exception
	    if (hotels.isEmpty()) {
	        throw new ResourceNotFoundException("Hotel", location);
	    }

	    // Initialize a map to store available rooms for each hotel
	    Map<Hotel, List<Room>> availableRoomsByHotel = new HashMap<>();

	    // For each hotel, get available rooms using the hotelId, startDate, and endDate
	    for (Hotel hotel : hotels) {
	        Long hotelId = hotel.getHotelId();
	        List<Room> availableRooms = roomRepos.findAvailableRoomsByHotelAndDates(hotelId, startDate, endDate);

	        // Add the available rooms for this hotel to the map
	        availableRoomsByHotel.put(hotel, availableRooms);
	    }

	    return availableRoomsByHotel; // Return a map of hotels and their available rooms
	}

	}

	


