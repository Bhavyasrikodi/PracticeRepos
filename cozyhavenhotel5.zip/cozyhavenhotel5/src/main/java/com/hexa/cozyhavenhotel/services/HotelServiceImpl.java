package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.HotelOwnerAlreadyExistsException;
import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.HotelDto;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;

@Service
public class HotelServiceImpl implements HotelService{
	@Autowired
	private ModelMapper modelMapper;
	 private HotelRepository hotelRepos;
	 private HotelOwnerRepository hotelOwnerRepos;
	 private HotelOwnerService hotelOwnerService;
	 
	 @Autowired
	public HotelServiceImpl( HotelRepository hotelRepos,HotelOwnerRepository hotelOwnerRepos,HotelOwnerService hotelOwnerService) {
		super();
		this.hotelRepos = hotelRepos;
		this.hotelOwnerRepos=hotelOwnerRepos;
		this.hotelOwnerService=hotelOwnerService;
		
	}

		 @Override
		 public Hotel createHotel(HotelDto hotelDto)throws ResourceNotFoundException {
			 Long ownerId=hotelDto.getOwnerId();
			 HotelOwner hotelOwner=hotelOwnerService.getOwnerById(ownerId);
			 Hotel existingHotel = hotelRepos.findByHotelOwner(hotelOwner);
			    if (existingHotel!=null) {
			        throw new HotelOwnerAlreadyExistsException("This hotel owner already has an associated hotel.");
			    }
			 Hotel hotel=this.modelMapper.map(hotelDto,Hotel.class);
			 hotel.setHotelOwner(hotelOwner);
			 return this.hotelRepos.save(hotel);
			 
		 }
		 
	

	 
	 //to get hotelid that would be used for inserting room
	 @Override
	 public Hotel getHotelById(long hotelId)throws ResourceNotFoundException{
		 Hotel hotel=this.hotelRepos.findById(hotelId).orElseThrow(()->new ResourceNotFoundException("hotel","hotelId",hotelId));
		 return hotel;
		 
	 }
	 

	    
	 @Override//gethotelbylocation
	 public List<Hotel> getHotelByLocation(String location)throws ResourceNotFoundException{
		 List<Hotel> hotels=this.hotelRepos.searchHotelsbylocation(location);
		 if (hotels.isEmpty()) {
	            throw new ResourceNotFoundException("hotel", "location");
	        }
		 return hotels;
	 }
	 
	 @Override
	 public List<Hotel> findHotelsByDates(String location,LocalDate startDate, LocalDate endDate)throws ResourceNotFoundException{
		 List<Hotel> hotels=hotelRepos.findHotelsWithAvailableRooms(location,startDate, endDate);
		 if (hotels.isEmpty()) {
	            throw new ResourceNotFoundException("hotel", "location");
	        }
		 return hotels;
	 }
//	 @Override
//	 public Hotel getHotelByName(String hotelName)throws ResourceNotFoundException{
//		 Hotel hotel=this.hotelRepos.searchHotelbyName(hotelName);
//		 return hotel;
//	 }

	 @Override//gethotellistings
	 public List<Hotel> getAllHotels() {
	        List<Hotel>hotels=hotelRepos.findAll(); 
		 return hotels;
	        
	    }
	 @Override
	 public Hotel updateHotelOwner(Long hotelId,Long ownerId)throws ResourceNotFoundException {
		 HotelOwner hotelOwner=this.hotelOwnerRepos.findById(ownerId).orElseThrow(()->new ResourceNotFoundException("hotelowner","hotelOwnerId",ownerId));
		 Hotel hotel=this.hotelRepos.findById(hotelId).orElseThrow(()->new ResourceNotFoundException("hotel","hotelId",hotelId));
		 hotel.setHotelOwner(hotelOwner);
		 return this.hotelRepos.save(hotel);
	 }
	 public Hotel updateHotelByOwnerId(Long hotelId)throws ResourceNotFoundException{
		 Hotel hotel=this.hotelRepos.findById(hotelId).orElseThrow(()->new ResourceNotFoundException("hotel","hotelId",hotelId));
		 Long ownerId=hotel.getHotelOwner().getOwnerId();
		 HotelOwner hotelOwner=this.hotelOwnerRepos.findById(ownerId).orElseThrow(()->new ResourceNotFoundException("hotel","hotelId",hotelId));
		 hotel.setHotelOwner(hotelOwner);
		 return this.hotelRepos.save(hotel);
		
	 }


}
