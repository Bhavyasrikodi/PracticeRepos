package com.hexa.cozyhavenhotel.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.HotelOutputDto;
import com.hexa.cozyhavenhotel.dtos.RoomDto;
import com.hexa.cozyhavenhotel.dtos.RoomOutputDto;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.services.RoomService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/room")
@CrossOrigin("http://localhost:3000")
public class RoomController {
	
	private final RoomService roomService;
	private final ModelMapper modelMapper;
	@Autowired
	public RoomController(RoomService roomService,ModelMapper modelMapper) {
		this.roomService = roomService;
		this.modelMapper = modelMapper;
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@PostMapping("/createRoom")
	public ResponseEntity<RoomOutputDto> createRoom(@Valid @RequestBody RoomDto roomDto,@RequestParam long hotelId)throws ResourceNotFoundException{
		Room room=this.roomService.creatRoom(hotelId, roomDto);
		RoomOutputDto roomOutputDto=this.modelMapper.map(room, RoomOutputDto.class);
		roomOutputDto.setHotelName(room.getHotel().getHotelName());
		roomOutputDto.setLocation(room.getHotel().getLocation());
		roomOutputDto.setHotelOwnerName(room.getHotel().getHotelOwner().getHotelOwnerName());
		roomOutputDto.setEmail(room.getHotel().getHotelOwner().getEmail());
		roomOutputDto.setPhoneNumber(room.getHotel().getHotelOwner().getPhoneNumber());
		return ResponseEntity.ok(roomOutputDto);
	}
	@PostMapping("/createMultiplesrooms")
	public ResponseEntity<List<RoomOutputDto>> creatMultipleRoom(@Valid @RequestBody List<RoomDto> listOfRooms ,@RequestParam Long hotelId) throws ResourceNotFoundException {
		List<Room> listofrooms=this.roomService.creatMultipleRoom(hotelId, listOfRooms);
		List<RoomOutputDto> listOfRoomdto=new ArrayList<>();
		for(Room room: listofrooms) {
			RoomOutputDto roomOutputDto=this.modelMapper.map(room, RoomOutputDto.class);
			roomOutputDto.setHotelName(room.getHotel().getHotelName());
			roomOutputDto.setLocation(room.getHotel().getLocation());
			roomOutputDto.setHotelOwnerName(room.getHotel().getHotelOwner().getHotelOwnerName());
			roomOutputDto.setEmail(room.getHotel().getHotelOwner().getEmail());
			roomOutputDto.setPhoneNumber(room.getHotel().getHotelOwner().getPhoneNumber());
			listOfRoomdto.add(roomOutputDto);
		}
		return ResponseEntity.ok(listOfRoomdto);
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getroomid")
	public ResponseEntity<RoomOutputDto> findById(@Valid @RequestParam("roomId") Long roomId)throws ResourceNotFoundException{
		Room room=this.roomService.getRoomById(roomId);
		RoomOutputDto roomOutputDto=this.modelMapper.map(room,RoomOutputDto.class);
		roomOutputDto.setHotelName(room.getHotel().getHotelName());
		roomOutputDto.setLocation(room.getHotel().getLocation());
		roomOutputDto.setHotelOwnerName(room.getHotel().getHotelOwner().getHotelOwnerName());
		roomOutputDto.setEmail(room.getHotel().getHotelOwner().getEmail());
		roomOutputDto.setPhoneNumber(room.getHotel().getHotelOwner().getPhoneNumber());
		return ResponseEntity.ok(roomOutputDto);
	}
	

	
	 @PostMapping("/addroombyowner")
	    public ResponseEntity<RoomOutputDto> addRoom(@RequestParam Long hotelOwnerId, 
	                                           @RequestParam Long hotelId, 
	                                           @RequestBody RoomDto roomDto) throws ResourceNotFoundException {
	       
	        Room room = roomService.addRoom(hotelOwnerId, hotelId, roomDto);
	        RoomOutputDto roomOutputdto = modelMapper.map(room, RoomOutputDto.class);
	        //RoomOutputDto roomOutputDto=this.modelMapper.map(room, RoomOutputDto.class);
			roomOutputdto.setHotelName(room.getHotel().getHotelName());
			roomOutputdto.setLocation(room.getHotel().getLocation());
			roomOutputdto.setHotelOwnerName(room.getHotel().getHotelOwner().getHotelOwnerName());
			roomOutputdto.setEmail(room.getHotel().getHotelOwner().getEmail());
			roomOutputdto.setPhoneNumber(room.getHotel().getHotelOwner().getPhoneNumber());
	        return ResponseEntity.ok(roomOutputdto);
	    }
	 @PreAuthorize("hasRole('HOTEL_OWNER')")
	 @PutMapping("/editroom")
	 public ResponseEntity<RoomOutputDto> editRoom(@RequestParam("roomId") Long roomId, @RequestBody RoomDto roomDto) throws ResourceNotFoundException {
	  Room room=roomService.editRoom(roomId, roomDto);
	  RoomOutputDto roomOutputdto=modelMapper.map(room,RoomOutputDto.class);
	  	roomOutputdto.setHotelName(room.getHotel().getHotelName());
		roomOutputdto.setLocation(room.getHotel().getLocation());
		roomOutputdto.setHotelOwnerName(room.getHotel().getHotelOwner().getHotelOwnerName());
		roomOutputdto.setEmail(room.getHotel().getHotelOwner().getEmail());
		roomOutputdto.setPhoneNumber(room.getHotel().getHotelOwner().getPhoneNumber());
      return ResponseEntity.ok(roomOutputdto);
	 }
	 @PreAuthorize("hasRole('HOTEL_OWNER')")
	 @DeleteMapping("/deleteroom")
	    public ResponseEntity<String> removeRoom(@RequestParam Long roomId) throws ResourceNotFoundException {
	        roomService.removeRoom( roomId);
	        return ResponseEntity.ok("Room with ID " + roomId + " was deleted successfully.");
	    }
	 @PreAuthorize("hasRole('GUEST')")
	 @GetMapping("/getroomsbyhotel")
	 public ResponseEntity<List<Room>> getRoomsByHoteldId(@Valid @RequestParam Long hotelId)throws ResourceNotFoundException{
		 List<Room> rooms = roomService.getRoomsByHotelId(hotelId);
		    return ResponseEntity.ok(rooms);
	 }
	
	 @PreAuthorize("hasRole('GUEST')")
	 @GetMapping("/availablerooms")
	 public ResponseEntity<Map<String, List<RoomOutputDto>>> getAvailableRoomsForHotels(
	         @RequestParam("location") String location,
	         @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
	         @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

	     try {
	         // Call the service method to find available rooms in hotels
	         Map<Hotel, List<Room>> availableRoomsByHotel = roomService.findAvailableRoomsForHotelsInLocation(location, startDate, endDate);

	         // Convert the result map (Hotel -> Room) to (HotelOutputDto -> RoomOutputDto)
	         Map<String, List<RoomOutputDto>> availableRoomsByHotelDto = availableRoomsByHotel.entrySet().stream()
	             .collect(Collectors.toMap(
	                 entry -> modelMapper.map(entry.getKey(), HotelOutputDto.class).getHotelName(), // Use hotel name as key
	                 entry -> entry.getValue().stream()                                           // Convert List<Room> to List<RoomOutputDto>
	                                .map(room -> modelMapper.map(room, RoomOutputDto.class))
	                                .collect(Collectors.toList())
	             ));

	         // Return the response with OK status and available rooms map
	         return ResponseEntity.ok(availableRoomsByHotelDto);

	     } catch (ResourceNotFoundException e) {
	         // If no hotels are found, return a NOT FOUND status with an empty map
	         return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.emptyMap());
	     }
	 }


	 }
