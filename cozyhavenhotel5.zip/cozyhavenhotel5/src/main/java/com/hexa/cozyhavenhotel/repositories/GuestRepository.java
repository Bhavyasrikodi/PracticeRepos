package com.hexa.cozyhavenhotel.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.hexa.cozyhavenhotel.models.Guest;

import jakarta.transaction.Transactional;
@Repository
public interface GuestRepository extends JpaRepository<Guest,Long>{
	@Query(value="select g.guest_id from guests g join users u on u.id=g.user_id where username=:username",nativeQuery=true)
	Long getGuestId(@RequestParam("username") String username);
	@Modifying 
	 @Transactional
	    @Query("DELETE FROM Payment r WHERE r.reservation.id = :reservationId")
	    void deleteByReservationId(@Param("reservationId") Long roomId);
	
}
