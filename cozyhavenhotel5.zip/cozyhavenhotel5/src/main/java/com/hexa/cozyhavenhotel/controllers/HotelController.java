package com.hexa.cozyhavenhotel.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.HotelDto;
import com.hexa.cozyhavenhotel.dtos.HotelOutputDto;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.services.HotelService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/hotel")
@ResponseBody
@CrossOrigin("http://localhost:3000")
public class HotelController {
	private final HotelService hotelService;
	private final ModelMapper modelMapper;

	 @Autowired
	public HotelController(HotelService hotelService,ModelMapper modelMapper) {

		this.hotelService = hotelService;
		this.modelMapper = modelMapper;
	}

	 @PreAuthorize("hasRole('HOTEL_OWNER')")
		@PostMapping("/createhotel")
		public ResponseEntity<HotelOutputDto> createHotel( @RequestBody HotelDto hotelDto ) throws ResourceNotFoundException {
			
			Hotel hotel=this.hotelService.createHotel( hotelDto);
			HotelOutputDto hotelOutputDto=this.modelMapper.map(hotel,HotelOutputDto.class);
			 hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
			hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
			hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
			hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());		 
			return ResponseEntity.ok(hotelOutputDto);
		}	
		@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/gethotelByid")
	 public ResponseEntity<HotelOutputDto> findById(@Valid @RequestParam("hotelId") long hotelId) throws ResourceNotFoundException {
        Hotel hotel = hotelService.getHotelById(hotelId);
        HotelOutputDto hotelOutputDto = modelMapper.map(hotel, HotelOutputDto.class);
        hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
		hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
		hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
		hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());		 
        return ResponseEntity.ok(hotelOutputDto);
    }
	

	@GetMapping("/gethotelsbylocation")
	public ResponseEntity<List<HotelOutputDto>> getHotelByLocation(@Valid @RequestParam("location") String location) throws ResourceNotFoundException {
	    // List to store the output DTOs
	    List<HotelOutputDto> listOfDtos = new ArrayList<>();

	    // Fetch the list of hotels from the service
	    List<Hotel> hotels = hotelService.getHotelByLocation(location);

	    // Loop through each hotel and map it to the DTO
	    for (Hotel hotel : hotels) {
	        // Map Hotel entity to HotelOutputDto using ModelMapper
	        HotelOutputDto hotelOutputDto = this.modelMapper.map(hotel, HotelOutputDto.class);
	        hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
			hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
			hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
			hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());		 
	        
	        listOfDtos.add(hotelOutputDto);  // This should now work
	    }

	    return ResponseEntity.ok(listOfDtos);
	}
	@PreAuthorize("hasRole('GUEST')")
	@GetMapping("/gethotelbyduration")
	public ResponseEntity<List<HotelOutputDto>> findHotelsByDates(@Valid @RequestParam String location, @RequestParam LocalDate startDate,@RequestParam LocalDate endDate)throws ResourceNotFoundException{
		List<HotelOutputDto> listOfDtos = new ArrayList<>();

	    // Fetch the list of hotels from the service
	    List<Hotel> hotels = hotelService.findHotelsByDates(location,startDate, endDate);
	    for (Hotel hotel : hotels) {
	        // Map Hotel entity to HotelOutputDto using ModelMapper
	        HotelOutputDto hotelOutputDto = this.modelMapper.map(hotel, HotelOutputDto.class);
	        hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
			hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
			hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
			hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());		 
	        
	        listOfDtos.add(hotelOutputDto);  // This should now work
	    }

	    return ResponseEntity.ok(listOfDtos);
	    
	}
//	@GetMapping
//	public List<Hotel> findHotelsWithRooms(Long hotelId,LocalDate startDate, LocalDate endDate)throws ResourceNotFoundException
	
	
	@PreAuthorize("hasRole('ADMIN') or hasRole('GUEST')")
	@GetMapping("/getallhotels")
	public ResponseEntity<List<HotelOutputDto>> getAllHotels() {
       
        List<HotelOutputDto> listofdtos=new ArrayList<>();
        List<Hotel>hotels=hotelService.getAllHotels(); 
        for (Hotel hotel : hotels) {
        	HotelOutputDto hotelOutputDto=this.modelMapper.map(hotel, HotelOutputDto.class);
        	hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
    		hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
    		hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
    		hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());		 

			listofdtos.add(hotelOutputDto);
		}
		return ResponseEntity.ok(listofdtos);
        }
        	
	@PutMapping("/updatehotel")
	public ResponseEntity<HotelOutputDto> updateHotelOwner(@Valid @RequestParam Long hotelId,@RequestParam Long ownerId)throws ResourceNotFoundException {
		Hotel hotel=this.hotelService.updateHotelOwner(hotelId, ownerId);
		HotelOutputDto hotelOutputDto=this.modelMapper.map(hotel, HotelOutputDto.class);
		hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
		hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
		hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
		hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());	
		return ResponseEntity.ok(hotelOutputDto);
		
	}
	@PutMapping("/updatehotelbyownerid")
	public ResponseEntity<HotelOutputDto> updateHotelByOwnerId(@Valid @RequestParam Long hotelId)throws ResourceNotFoundException{
		Hotel hotel =this.hotelService.updateHotelByOwnerId(hotelId);
		
		HotelOutputDto hotelOutputDto=this.modelMapper.map(hotel, HotelOutputDto.class);
		hotelOutputDto.setHotelOwnerName(hotel.getHotelOwner().getHotelOwnerName());
		hotelOutputDto.setEmail(hotel.getHotelOwner().getEmail());
		hotelOutputDto.setBusinessLicense(hotel.getHotelOwner().getBusinessLicense());
		hotelOutputDto.setPhoneNumber(hotel.getHotelOwner().getPhoneNumber());	
		return ResponseEntity.ok(hotelOutputDto);
	}
//	public ResponseEntity<HotelOutputDto getHotelByName(String hotelName)throws ResourceNotFoundException 	{
//		
//	}
//        
    }



