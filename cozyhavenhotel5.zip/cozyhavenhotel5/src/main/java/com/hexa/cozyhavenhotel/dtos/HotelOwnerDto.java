package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.Role;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class HotelOwnerDto {
	
	  private Long ownerId;
	@NotNull
	@Size(min = 2, max = 50)
    private String hotelOwnerName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String phoneNumber;
    @NotNull
    private String businessLicense;
   
	
    @Enumerated(EnumType.STRING)
   	private Role role;


	public Long getOwnerId() {
		return ownerId;
	}


	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}


	public String getHotelOwnerName() {
		return hotelOwnerName;
	}


	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getBusinessLicense() {
		return businessLicense;
	}


	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}


	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	

	public HotelOwnerDto(Long ownerId, @NotNull @Size(min = 2, max = 50) String hotelOwnerName,
			@NotNull @Email String email, @NotNull String phoneNumber, @NotNull String businessLicense, Role role) {
		super();
		this.ownerId = ownerId;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.businessLicense = businessLicense;
		this.role = role;
	}


	public HotelOwnerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}