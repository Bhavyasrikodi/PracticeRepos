package com.hexa.cozyhavenhotel.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "hotel_owners")
public class HotelOwner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;
    @NotNull
	@Size(min = 2, max = 50)
    private String hotelOwnerName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String phoneNumber;
    @NotNull
    private String businessLicense;
    
    
    @OneToOne
    private User user;
	
    
    public Long getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}
	public String getHotelOwnerName() {
		return hotelOwnerName;
	}
	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getBusinessLicense() {
		return businessLicense;
	}
	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public HotelOwner() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HotelOwner(Long ownerId, @NotNull @Size(min = 2, max = 50) String hotelOwnerName,
			@NotNull @Email String email,  @NotNull String phoneNumber, @NotNull String businessLicense, User user) {
		super();
		this.ownerId = ownerId;
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.businessLicense = businessLicense;
		this.user = user;
	}
	public HotelOwner(@NotNull @Size(min = 2, max = 50) String hotelOwnerName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull String businessLicense) {
		super();
		this.hotelOwnerName = hotelOwnerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.businessLicense = businessLicense;
	}

	
   
    
}