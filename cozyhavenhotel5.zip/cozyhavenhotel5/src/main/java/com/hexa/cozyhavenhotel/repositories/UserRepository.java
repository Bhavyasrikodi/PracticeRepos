package com.hexa.cozyhavenhotel.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hexa.cozyhavenhotel.models.User;




public interface UserRepository extends JpaRepository<User, Integer> {

	@Query("select u from User u where u.username = :username")
	User getUserByUsername(String username);
	
	User findUserByUsername(String username);
	
	boolean existsByUsername(String username);

}