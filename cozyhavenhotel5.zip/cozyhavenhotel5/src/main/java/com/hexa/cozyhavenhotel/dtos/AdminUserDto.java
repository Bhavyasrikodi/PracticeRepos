package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.Role;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class AdminUserDto {
	
	
	@NotNull
	@Size(min = 2, max = 50)
    private String adminName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String phoneNumber;
    @NotNull
    private String adminLevel;
    @Column(nullable = false)
	private String username;

	private String password; 

	@NotNull
	@Enumerated(EnumType.STRING)
	private Role role;

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAdminLevel() {
		return adminLevel;
	}

	public void setAdminLevel(String adminLevel) {
		this.adminLevel = adminLevel;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public AdminUserDto(@NotNull @Size(min = 2, max = 50) String adminName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull String adminLevel, String username, String password,
			@NotNull Role role) {
		super();
		this.adminName = adminName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.adminLevel = adminLevel;
		this.username = username;
		this.password = password;
		this.role = role;
	}

	public AdminUserDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}