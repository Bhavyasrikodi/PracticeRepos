package com.hexa.cozyhavenhotel.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexa.cozyhavenhotel.models.Payment;

import jakarta.transaction.Transactional;
@Repository
public interface PaymentRepository extends JpaRepository<Payment,Long> {
	@Query("SELECT p FROM Payment p WHERE p.reservation.id = :reservationId")
    List<Payment> findByReservationId(@Param("reservationId") Long reservationId);
	@Modifying
	@Transactional
    @Query("DELETE FROM Payment r WHERE r.guest.id = :guestId")
    void deleteByGuestId(@Param("guestId") Long guestId);
	
//	@Modifying 
//	 @Transactional
//	    @Query("DELETE FROM Payment r WHERE r.reservation.id = :reservationId")
//	    void deleteByReservationId(@Param("reservationId") Long roomId);
	 
	 @Query("SELECT p.amount, p.paymentDate, p.paymentStatus, r.guest.id " +
	           "FROM Payment p " +
	           "JOIN p.reservation r " +
	           "JOIN r.room rm " +
	           "JOIN rm.hotel h " +
	           "WHERE( p.paymentStatus = 'PENDING_REFUND' AND h.id = :hotelId)")
	    List<Object[]> findPendingRequestPaymentsByHotelId(@Param("hotelId") Long hotelId);
	    
	    @Modifying
		 @Transactional
		    @Query(value="delete p.* from payments p join reservations r"
		    		+ " on p.reservation_id = r.reservation_id join rooms rm"
		    		+ " on r.room_id=rm.room_id where r.room_id=:roomId",nativeQuery=true)
		    void deleteByReservationId(@Param("roomId") Long roomId);
	    @Modifying
		 @Transactional
		    @Query(value="delete p.* from payments p where p.reservation_id=:reservationId",nativeQuery=true)
		    void deleteReservationId(@Param("reservationId") Long reservationId);
	    
	    
	    
	    
}
