package com.hexa.cozyhavenhotel.services;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.models.Admin;


public interface AdminService {
	public Admin createAdmin(AdminGuestOwnerDto adminGuestOwnerDto);
	public void deleteGuest(Long guestId) throws ResourceNotFoundException;
	
	public void deleteHotelOwner(Long hotelOwnerId) throws ResourceNotFoundException ;
	
	
}
