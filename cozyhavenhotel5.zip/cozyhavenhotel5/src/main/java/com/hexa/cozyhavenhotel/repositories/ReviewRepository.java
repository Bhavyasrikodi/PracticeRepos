package com.hexa.cozyhavenhotel.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexa.cozyhavenhotel.models.Review;

import jakarta.transaction.Transactional;
@Repository
public interface ReviewRepository extends JpaRepository<Review,Long>{
	//void deleteByGuestId(Long guestId);
	@Modifying
	@Transactional
    @Query("DELETE FROM Review r WHERE r.guest.id = :guestId")
    void deleteByGuestId(@Param("guestId") Long guestId);
	
	@Modifying
	@Query("DELETE FROM Review r WHERE r.hotel.id = :hotelId")
	void deleteByHotelId(@Param("hotelId") Long hotelId);

	
}
