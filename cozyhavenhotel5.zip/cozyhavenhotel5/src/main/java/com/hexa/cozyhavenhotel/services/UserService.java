package com.hexa.cozyhavenhotel.services;

public interface UserService {

}
