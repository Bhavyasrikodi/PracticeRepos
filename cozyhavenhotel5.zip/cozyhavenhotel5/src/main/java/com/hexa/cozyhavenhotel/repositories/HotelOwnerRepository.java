package com.hexa.cozyhavenhotel.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.hexa.cozyhavenhotel.models.HotelOwner;
@Repository
public interface HotelOwnerRepository extends JpaRepository<HotelOwner,Long>{
	//public HotelOwner findByHotel(Hotel hotel);
	@Query(value="select rs.reservation_id,rs.start_date,rs.end_date,rs.number_of_persons,"
			+ "rs.number_of_rooms,rs.reservation_status,rs.total_price,rs.room_id,rs.guest_id"
			+ " from reservations rs join rooms r "
			+ "on rs.room_id=r.room_id join hotels h"
			+ " on h.hotel_id=r.hotel_id where h.hotel_id=:hotelId",nativeQuery=true)
	List<Object[]> getRawReservationsOfHotel(@RequestParam("hotelId") Long hotelId);
	
	@Query(value="select distinct g.guest_id,g.aadhar_number,g.email,g.gender,g.guest_address,g.guest_name,g.phone_number from guests g join reservations rs \r\n"
			+ " on g.guest_id=rs.guest_id join rooms r \r\n"
			+ " on rs.room_id=r.room_id join hotels h\r\n"
			+ " on r.hotel_id=h.hotel_id \r\n"
			+ " where h.hotel_id=:hotelId",nativeQuery=true)
	List<Object[]> getRawGuestsOfHotel(@RequestParam("hotelId") Long hotelId);
	
	@Query(value="select r.room_id,r.availability,r.base_fare,r.bed_preferences,r.is_ac,r.max_occupancy,r.room_number"
			+ " from rooms r where r.hotel_id=:hotelId",nativeQuery=true)
	List<Object[]> getRawRoomsOfHotel(@RequestParam("hotelId") Long hotelId);
	
	@Query(value="select h.hotel_id "
			+ "from hotels h join hotel_owners o"
			+ " on o.owner_id = h.hotel_owner_id"
			+ " join users u "
			+ "on u.id =o.user_id"
			+ " where u.username=:username",nativeQuery=true)
	Long getHotelId(@RequestParam("username") String username);
	
	

	
	@Query(value="select p.payment_id,p.amount,p.payment_date,p.payment_status,r.guest_id"
				+ "  from payments p join reservations r "
			+ "  on p.reservation_id=r.reservation_id"
			+ " join rooms rm on rm.room_id = r.room_id"
			+ " join hotels h on h.hotel_id=rm.hotel_id where p.payment_status='PENDING_REFUND' and h.hotel_id=:hotelId",nativeQuery=true)
    List<Object[]> findPendingRequestPaymentsByHotelId(@Param("hotelId") Long hotelId);
    
    @Query(value="select u.username from users u join guests g on u.id=g.user_id where g.guest_id=:guestId",nativeQuery=true)
    String getUsernameById(@Param("guestId") Long guestId);
    
    @Query(value= "select owner_id from hotel_owners h join users u "
    		+ "on u.id=h.user_id where u.username=:username",nativeQuery=true)
    Long getOwnerId(@Param("username") String username);
    
    @Query(value="select r.rating,r.review_text,r.guest_id from reviews r where hotel_id=:hotelId",nativeQuery=true)
    List<Object[]> getReviewsOfHotel(@Param("hotelId")Long hotelId);
    
}
