package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.util.List;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.ReservationDto;
import com.hexa.cozyhavenhotel.dtos.RoomDto;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.models.Reservation;

public interface ReservationService {

	public Reservation doReservation(Long GuestId,Long roomId,double calculateTotalFare,ReservationDto reservationDto)throws ResourceNotFoundException;
	public Reservation getReservationById(Long reservationId)throws ResourceNotFoundException;
	public List<Reservation> getReservationByGuestId(Long guestId)throws ResourceNotFoundException;
	public Reservation cancelReservationAndRequestRefund(Long reservationId)throws ResourceNotFoundException;
	public Payment processRefund(Long paymentId)throws ResourceNotFoundException;
	public List<Reservation> getReservationsByHotelOwner(Long hotelOwnerId) throws ResourceNotFoundException;
	public Reservation reserveRoom(Long guestId,Long roomId, int numberOfPersons, int numberOfAdults, int numberOfChildren, int numberOfRooms, LocalDate startDate, LocalDate endDate,ReservationDto reservationDto)throws ResourceNotFoundException;
	public List<Reservation> getAllReservations();
	public Reservation reservesRoom(Long guestId,Long roomId,ReservationDto reservationDto)throws ResourceNotFoundException;
}
