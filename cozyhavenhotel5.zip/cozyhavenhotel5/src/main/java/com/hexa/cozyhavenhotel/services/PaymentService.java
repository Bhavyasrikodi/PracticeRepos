package com.hexa.cozyhavenhotel.services;

import java.util.List;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.PaymentDto;
import com.hexa.cozyhavenhotel.dtos.PaymentOutputDto;
import com.hexa.cozyhavenhotel.models.Payment;

public interface PaymentService {
	public Payment payNow(Long guestId,Long reservationId,PaymentDto paymentDto)throws ResourceNotFoundException;
	public List<Object[]> getPendingRequestPaymentsByHotelId(Long hotelId);
	public byte[] generatePaymentBill(PaymentDto paymentDto);
	public Payment getPaymentById(Long paymentId) throws ResourceNotFoundException;
}
