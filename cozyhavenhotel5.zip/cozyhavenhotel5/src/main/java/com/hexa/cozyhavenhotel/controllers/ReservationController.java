package com.hexa.cozyhavenhotel.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.PaymentOutputDto;
import com.hexa.cozyhavenhotel.dtos.ReservationDto;
import com.hexa.cozyhavenhotel.dtos.ReservationOutputDto;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.services.ReservationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/reservation")
@CrossOrigin("http://localhost:3000")
public class ReservationController {
	
	private final ModelMapper modelMapper;

	private final ReservationService reservationService;
	@Autowired
	public ReservationController(ReservationService reservationService,ModelMapper modelMapper) {
		super();
		this.reservationService = reservationService;
		this.modelMapper =modelMapper;
	}
	
	@PostMapping("/BookRoom")
	public ResponseEntity<ReservationOutputDto> doReservation(@Valid @RequestParam Long guestId,@RequestParam Long roomId,@RequestParam double calculateTotalFare, @RequestBody ReservationDto reservationDto)throws ResourceNotFoundException{
		Reservation reservation=this.reservationService.doReservation(guestId, roomId,calculateTotalFare, reservationDto);
		ReservationOutputDto reservationOutputDto=this.modelMapper.map(reservation, ReservationOutputDto.class);
		reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
		reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
		reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
		reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
		reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
		reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
		reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
		reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
		return ResponseEntity.ok(reservationOutputDto);
		
		
	}
	@GetMapping("/getreservationbyid")
	public ResponseEntity<ReservationOutputDto> findById(@Valid @RequestParam Long reservationId) throws ResourceNotFoundException {
		Reservation reservation=this.reservationService.getReservationById(reservationId);
		ReservationOutputDto reservationOutputDto=this.modelMapper.map(reservation, ReservationOutputDto.class);
		reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
		reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
		reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
		reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
		reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
		reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
		reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
		reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
		return ResponseEntity.ok(reservationOutputDto);
		
	}
	@PreAuthorize("hasRole('GUEST')")
	@GetMapping("/getreservationbyguestId")
	public ResponseEntity<List<ReservationOutputDto>> getReservationByGuestId(@Valid @RequestParam("guestId") Long guestId)throws ResourceNotFoundException{
		
		List<ReservationOutputDto> listofdtos=new ArrayList<ReservationOutputDto>();
		List<Reservation> reservations = reservationService.getReservationByGuestId(guestId);
		for(Reservation reservation:reservations) {
			ReservationOutputDto reservationOutputDto=this.modelMapper.map(reservation,ReservationOutputDto.class);
			reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
			reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
			reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
			reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
			reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
			reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
			reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
			reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
            listofdtos.add(reservationOutputDto);
           }
		return ResponseEntity.ok(listofdtos);
	}
	
	
	@PreAuthorize("hasRole('GUEST')")
		@PutMapping("/cancelByreservationId")
	    public ResponseEntity<ReservationOutputDto> cancelReservationAndRequestRefund(@Valid @RequestParam("reservationId") Long reservationId) throws ResourceNotFoundException {

	        Reservation reservation = reservationService.cancelReservationAndRequestRefund(reservationId);
	        ReservationOutputDto reservationOutputDto = modelMapper.map(reservation, ReservationOutputDto.class);
	        reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
			reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
			reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
			reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
			reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
			reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
			reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
			reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
	        
	        return ResponseEntity.ok(reservationOutputDto);
	    }
		
		@PutMapping("/refundBypaymentId")
	    public ResponseEntity<PaymentOutputDto> processRefund(@Valid @RequestParam("paymentId") Long paymentId) throws ResourceNotFoundException {

	        Payment payment = reservationService.processRefund(paymentId);
	        PaymentOutputDto paymentOutputdto=this.modelMapper.map(payment,PaymentOutputDto.class);
			paymentOutputdto.setReservationStatus(payment.getReservation().getReservationStatus());
			paymentOutputdto.setRoomNumber(payment.getReservation().getRoom().getRoomNumber());
			paymentOutputdto.setHotelName(payment.getReservation().getRoom().getHotel().getHotelName());
			paymentOutputdto.setGuestName(payment.getGuest().getGuestName());
			paymentOutputdto.setPhoneNumber(payment.getGuest().getPhoneNumber());
	        return ResponseEntity.ok(paymentOutputdto);
	    }
		

		@GetMapping("/getreservationbyhotelowner")
		public ResponseEntity<List<ReservationOutputDto>> getReservationsByHotelOwner(@Valid @RequestParam Long hotelOwnerId) throws ResourceNotFoundException {
		    List<Reservation> reservations = reservationService.getReservationsByHotelOwner(hotelOwnerId);
		    List<ReservationOutputDto> listofdtos = new ArrayList<>();
		    
		    for (Reservation reservation : reservations) {
		        ReservationOutputDto reservationOutputDto = this.modelMapper.map(reservation, ReservationOutputDto.class);
		        reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
		        reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
		        reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
		        reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
		        reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
		        reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
		        reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
		        reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
		        
		        listofdtos.add(reservationOutputDto);
		    }
		    
		    return ResponseEntity.ok(listofdtos);
		}

		@PostMapping("/reserverooom")
		public ResponseEntity<ReservationOutputDto> reserveRoom(@Valid @RequestParam Long guestId, @RequestParam Long roomId,@RequestParam int numberOfPersons,@RequestParam int numberOfAdults,
				@RequestParam int numberOfChildren,@RequestParam  int numberOfRooms, @RequestParam LocalDate startDate,@RequestParam LocalDate endDate,@RequestBody ReservationDto reservationDto)
				throws ResourceNotFoundException{
			Reservation reservation=this.reservationService.reserveRoom(guestId, roomId, numberOfPersons, numberOfAdults, numberOfChildren, numberOfRooms, startDate, endDate, reservationDto);
			ReservationOutputDto reservationOutputDto=this.modelMapper.map(reservation, ReservationOutputDto.class);
			reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
			reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
			reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
			reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
			reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
			reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
			reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
			reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
			return ResponseEntity.ok(reservationOutputDto);
		}
		@PreAuthorize("hasRole('ADMIN')")
		@GetMapping("/getallreservations")
		public ResponseEntity<List<ReservationOutputDto>> getAllReservation() {
			List<ReservationOutputDto> listofdtos=new ArrayList<ReservationOutputDto>();
			List<Reservation> reservations=reservationService.getAllReservations();
			 for (Reservation reservation : reservations) {
			        ReservationOutputDto reservationOutputDto = this.modelMapper.map(reservation, ReservationOutputDto.class);
			        reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
			        reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
			        reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
			        reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
			        reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
			        reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
			        reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
			        reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
			        
			        listofdtos.add(reservationOutputDto);
			    }
			    
			    return ResponseEntity.ok(listofdtos);
			
		}
		@PreAuthorize("hasRole('GUEST')")
		@PostMapping("/reservesRooms")
		public ResponseEntity<ReservationOutputDto> reservesRoom(@Valid @RequestParam Long guestId, @RequestParam Long roomId,@RequestBody ReservationDto reservationDto)throws ResourceNotFoundException{
			Reservation reservation=this.reservationService.reservesRoom(guestId, roomId, reservationDto);
			ReservationOutputDto reservationOutputDto=this.modelMapper.map(reservation, ReservationOutputDto.class);
			reservationOutputDto.setRoomNumber(reservation.getRoom().getRoomNumber());
			reservationOutputDto.setBedPreferences(reservation.getRoom().getBedPreferences());
			reservationOutputDto.setHotelName(reservation.getRoom().getHotel().getHotelName());
			reservationOutputDto.setLocation(reservation.getRoom().getHotel().getLocation());
			reservationOutputDto.setHotelOwnerName(reservation.getRoom().getHotel().getHotelOwner().getHotelOwnerName());
			reservationOutputDto.setBusinessLicense(reservation.getRoom().getHotel().getHotelOwner().getBusinessLicense());
			reservationOutputDto.setGuestName(reservation.getGuest().getGuestName());
			reservationOutputDto.setPhoneNumber(reservation.getGuest().getPhoneNumber());
			return ResponseEntity.ok(reservationOutputDto);
		}
		
		
		
	}










