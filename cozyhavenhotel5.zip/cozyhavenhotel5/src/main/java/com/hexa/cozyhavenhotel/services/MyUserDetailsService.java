
  package com.hexa.cozyhavenhotel.services;
  
  import java.util.Collections;
  
  import org.springframework.beans.factory.annotation.Autowired; 
  import org.springframework.security.core.authority.SimpleGrantedAuthority; 
  import org.springframework.security.core.userdetails.UserDetails; 
  import org.springframework.security.core.userdetails.UserDetailsService; 
  import org.springframework.security.core.userdetails.UsernameNotFoundException;
  import org.springframework.stereotype.Service;
  
  import com.hexa.cozyhavenhotel.models.User; 
  import com.hexa.cozyhavenhotel.repositories.UserRepository;
  
  @Service 
  public class MyUserDetailsService implements UserDetailsService{
  
  @Autowired 
  private UserRepository userRepository;
  
  
  @Override 
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException { 
	  User userInfo =userRepository.getUserByUsername(username);
  
  if (userInfo == null) { 
	  throw new UsernameNotFoundException("User not found with username: " + username); 
	  }
  
  String roleName ="ROLE_"+userInfo.getRole().name();
  
  return new org.springframework.security.core.userdetails.User(
		  	userInfo.getUsername(), 
		  	userInfo.getPassword(), 
		  	Collections.singletonList(new SimpleGrantedAuthority(roleName)) 
		  );
  
  } }
 