package com.hexa.cozyhavenhotel.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexa.cozyhavenhotel.models.Admin;

public interface AdminRepository extends JpaRepository<Admin,Long>{

}
