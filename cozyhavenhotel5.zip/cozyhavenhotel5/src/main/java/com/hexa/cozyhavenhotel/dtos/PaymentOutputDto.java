package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.PaymentStatus;
import com.hexa.cozyhavenhotel.enums.ReservationStatus;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public class PaymentOutputDto {
	
	private Long paymentId;
	private Double amount;
    private LocalDate paymentDate;
    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;
    @Enumerated(EnumType.STRING)
    private ReservationStatus reservationStatus; 
    private String roomNumber;
    private String hotelName;
    private String guestName;
    private String phoneNumber;
    
    
	public Long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public LocalDate getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public ReservationStatus getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public PaymentOutputDto(Long paymentId, Double amount, LocalDate paymentDate, PaymentStatus paymentStatus,
			ReservationStatus reservationStatus, String roomNumber, String hotelName, String guestName,
			String phoneNumber) {
		super();
		this.paymentId = paymentId;
		this.amount = amount;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
		this.reservationStatus = reservationStatus;
		this.roomNumber = roomNumber;
		this.hotelName = hotelName;
		this.guestName = guestName;
		this.phoneNumber = phoneNumber;
	}
	public PaymentOutputDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
