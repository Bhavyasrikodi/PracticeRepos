package com.hexa.cozyhavenhotel.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "guests")
public class Guest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long guestId;
    @NotNull
	@Size(min = 2, max = 50)
    private String guestName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String phoneNumber;
    @NotNull
	@Pattern(regexp = "^(Male|Female|Other)$")
	private String gender;
	
    @NotNull
	@Size(min = 2, max = 50)
    private String guestAddress;
    @NotNull
    private String aadharNumber;
    @OneToOne
    private User user;
	
    
    public String getGuestAddress() {
		return guestAddress;
	}

	public void setGuestAddress(String guestAddress) {
		this.guestAddress = guestAddress;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
	
	public Guest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getGuestId() {
		return guestId;
	}

	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Guest(Long guestId, @NotNull @Size(min = 2, max = 50) String guestName, @NotNull @Email String email,
			 @NotNull String phoneNumber, @NotNull @Pattern(regexp = "^(Male|Female|Other)$") String gender,@NotNull String aadharNumber, @NotNull String guestAddress,User user) {
		super();
		this.guestId = guestId;
		this.guestName = guestName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.gender=gender;
		this.aadharNumber = aadharNumber;
		this.guestAddress=guestAddress;
		this.user=user;
		
	}

	public Guest(Long guestId, @NotNull @Size(min = 2, max = 50) String guestName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull @Pattern(regexp = "^(Male|Female|Other)$") String gender,
			@NotNull @Size(min = 2, max = 50) String guestAddress, @NotNull String aadharNumber) {
		super();
		this.guestId = guestId;
		this.guestName = guestName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.guestAddress = guestAddress;
		this.aadharNumber = aadharNumber;
	}

	public Guest(@NotNull @Size(min = 2, max = 50) String guestName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull @Pattern(regexp = "^(Male|Female|Other)$") String gender,
			@NotNull @Size(min = 2, max = 50) String guestAddress, @NotNull String aadharNumber) {
		super();
		this.guestName = guestName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.guestAddress = guestAddress;
		this.aadharNumber = aadharNumber;
		
	}
	
    

}
