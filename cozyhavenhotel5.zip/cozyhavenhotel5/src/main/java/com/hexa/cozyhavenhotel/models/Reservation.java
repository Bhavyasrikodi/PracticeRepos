package com.hexa.cozyhavenhotel.models;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.ReservationStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "reservations")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reservationId;

    @ManyToOne
    @JoinColumn(name = "guest_id", referencedColumnName = "guestId")
    private Guest guest;

    @ManyToOne
    @JoinColumn(name = "room_id", referencedColumnName = "roomId")
    private Room room;
    private LocalDate endDate;
    private Double totalPrice;
    private Integer numberOfPersons;
    private Integer numberOfRooms;
    private Integer numberOfAdults;
    private Integer numberOfChildren;

    @Enumerated(EnumType.STRING)
    private ReservationStatus reservationStatus;  // Booked, Cancelled
    private LocalDate startDate;
    
    
    
    

	public Reservation(Long reservationId, Guest guest, Room room, LocalDate startDate, LocalDate endDate,
			Double totalPrice, Integer numberOfPersons, Integer numberOfRooms, Integer numberOfAdults,
			Integer numberOfChildren, ReservationStatus reservationStatus) {
		super();
		this.reservationId = reservationId;
		this.guest = guest;
		this.room = room;
		this.startDate = startDate;
		this.endDate = endDate;
		this.totalPrice = totalPrice;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.reservationStatus = reservationStatus;
	}

	
    
    public Reservation() {
        super();
    }

    public Reservation(Long reservationId, Guest guest, Room room, LocalDate startDate, LocalDate endDate,
                       Double totalPrice, Integer numberOfPersons, Integer numberOfRooms, ReservationStatus reservationStatus) {
        super();
        this.reservationId = reservationId;
        this.guest = guest;
        this.room = room;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalPrice = totalPrice;
        this.numberOfPersons = numberOfPersons;
        this.numberOfRooms = numberOfRooms;
        
        this.reservationStatus = reservationStatus;
    }

    
    public Integer getNumberOfAdults() {
		return numberOfAdults;
	}

	public void setNumberOfAdults(Integer numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}

	public Integer getNumberOfChildren() {
		return numberOfChildren;
	}

	public void setNumberOfChildren(Integer numberOfChildren) {
		this.numberOfChildren = numberOfChildren;
	}
    public Integer getNumberOfPersons() {
        return numberOfPersons;
    }

    public void setNumberOfPersons(Integer numberOfPersons) {
        this.numberOfPersons = numberOfPersons;
    }

    public Integer getNumberOfRooms() {
        return numberOfRooms;
    }

    public void setNumberOfRooms(Integer numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    public ReservationStatus getReservationStatus() {
        return reservationStatus;
    }

    public void setReservationStatus(ReservationStatus reservationStatus) {
        this.reservationStatus = reservationStatus;
    }

    public Long getReservationId() {
        return reservationId;
    }

    public void setReservationId(Long reservationId) {
        this.reservationId = reservationId;
    }

    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }



	public Reservation(LocalDate endDate, Double totalPrice, Integer numberOfPersons, Integer numberOfRooms,
			Integer numberOfAdults, Integer numberOfChildren, ReservationStatus reservationStatus,
			LocalDate startDate) {
		super();
		this.endDate = endDate;
		this.totalPrice = totalPrice;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.reservationStatus = reservationStatus;
		this.startDate = startDate;
	}
    
    
}
