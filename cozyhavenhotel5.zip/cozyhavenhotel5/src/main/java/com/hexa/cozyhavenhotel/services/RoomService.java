package com.hexa.cozyhavenhotel.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.RoomDto;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.Room;

@Service
public interface RoomService {
	public Room creatRoom(Long hotelId,RoomDto RoomDto)throws ResourceNotFoundException;
	public List<Room> creatMultipleRoom(Long hotelId,List<RoomDto> listOfRoomdtos)throws ResourceNotFoundException;
	public Room getRoomById(Long roomId)throws ResourceNotFoundException;
	public Room addRoom(Long hotelOwnerId,Long hotelId,RoomDto RoomDto)throws ResourceNotFoundException;
	public void removeRoom(Long roomId) throws ResourceNotFoundException;
	//public Room editRoom(Long hotelOwnerId,Long hotelId, Long roomId, RoomDto roomDto) throws ResourceNotFoundException;
	public List<Room> getRoomsByHotelId(Long hotelId)throws ResourceNotFoundException;
	public Map<Hotel, List<Room>> findAvailableRoomsForHotelsInLocation(String location, LocalDate startDate, LocalDate endDate) throws ResourceNotFoundException;
	public Room editRoom(Long roomId, RoomDto roomDto) throws ResourceNotFoundException;
}