package com.hexa.cozyhavenhotel.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "hotels")
public class Hotel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long hotelId;

    private String hotelName;
    private String location;
    private Boolean isDining;
    private Boolean isParking;
    private Boolean isfreeWifi;
    private Boolean isRoomservice;
    private Boolean isswimmingPool;
    private Boolean isFitnessCenter;
    private String imageurl;
    private Double rating;
    @OneToOne
    @JoinColumn(name = "hotel_owner_id")
    //@JoinColumn(name = "hotel_id", referencedColumnName = "hotelId")
    private HotelOwner hotelOwner;
   
    @OneToMany(mappedBy = "hotel")
    @JsonManagedReference
    private List<Room> rooms;
    

    public Hotel(Long hotelId, String hotelName, String location, Boolean isDining, Boolean isParking,
			Boolean isfreeWifi, Boolean isRoomservice, Boolean isswimmingPool, Boolean isFitnessCenter, String imageurl,
			Double rating, HotelOwner hotelOwner, List<Room> rooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.isDining = isDining;
		this.isParking = isParking;
		this.isfreeWifi = isfreeWifi;
		this.isRoomservice = isRoomservice;
		this.isswimmingPool = isswimmingPool;
		this.isFitnessCenter = isFitnessCenter;
		this.imageurl = imageurl;
		this.rating = rating;
		this.hotelOwner = hotelOwner;
		this.rooms = rooms;
	}

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	
	
	public Hotel(Long hotelId, String hotelName, String location, Boolean isDining, Boolean isParking, Boolean isfreeWifi,
			Boolean isRoomservice, Boolean isswimmingPool, Boolean isFitnessCenter, HotelOwner hotelOwner,
			List<Room> rooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.isDining = isDining;
		this.isParking = isParking;
		this.isfreeWifi = isfreeWifi;
		this.isRoomservice = isRoomservice;
		this.isswimmingPool = isswimmingPool;
		this.isFitnessCenter = isFitnessCenter;
		this.hotelOwner = hotelOwner;
		this.rooms = rooms;
	}

	/*
	 * public Hotel(HotelDto hotelDto) { this.hotelOwner=hoteDto.set }
	 */
	public Boolean getIsDining() {
		return isDining;
	}

	public void setIsDining(Boolean isDining) {
		this.isDining = isDining;
	}

	public Boolean getIsParking() {
		return isParking;
	}

	public void setIsParking(Boolean isParking) {
		this.isParking = isParking;
	}

	public Boolean getIsfreeWifi() {
		return isfreeWifi;
	}

	public void setIsfreeWifi(Boolean isfreeWifi) {
		this.isfreeWifi = isfreeWifi;
	}

	public Boolean getIsRoomservice() {
		return isRoomservice;
	}

	public void setIsRoomservice(Boolean isRoomservice) {
		this.isRoomservice = isRoomservice;
	}

	public Boolean getIsswimmingPool() {
		return isswimmingPool;
	}

	public void setIsswimmingPool(Boolean isswimmingPool) {
		this.isswimmingPool = isswimmingPool;
	}

	public Boolean getIsFitnessCenter() {
		return isFitnessCenter;
	}

	public void setIsFitnessCenter(Boolean isFitnessCenter) {
		this.isFitnessCenter = isFitnessCenter;
	}

	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public HotelOwner getHotelOwner() {
		return hotelOwner;
	}

	public void setHotelOwner(HotelOwner hotelOwner) {
		this.hotelOwner = hotelOwner;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}

	public Hotel(String hotelName, String location, Boolean isDining, Boolean isParking, Boolean isfreeWifi,
			Boolean isRoomservice, Boolean isswimmingPool, Boolean isFitnessCenter, String imageurl, Double rating) {
		super();
		this.hotelName = hotelName;
		this.location = location;
		this.isDining = isDining;
		this.isParking = isParking;
		this.isfreeWifi = isfreeWifi;
		this.isRoomservice = isRoomservice;
		this.isswimmingPool = isswimmingPool;
		this.isFitnessCenter = isFitnessCenter;
		this.imageurl = imageurl;
		this.rating = rating;
	}
    
    
    
}
