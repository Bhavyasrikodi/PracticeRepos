package com.hexa.cozyhavenhotel.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "admins")
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long adminId;
    @NotNull
	@Size(min = 2, max = 50)
    private String adminName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private  String phoneNumber;
    @NotNull
    private String adminLevel;
    
    @OneToOne
    private User user;

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAdminLevel() {
		return adminLevel;
	}

	public void setAdminLevel(String adminLevel) {
		this.adminLevel = adminLevel;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Admin(@NotNull @Size(min = 2, max = 50) String adminName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull String adminLevel) {
		super();
		this.adminName = adminName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.adminLevel = adminLevel;
	}

	public Admin(Long adminId, @NotNull @Size(min = 2, max = 50) String adminName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull String adminLevel, User user) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.adminLevel = adminLevel;
		this.user = user;
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

    
}