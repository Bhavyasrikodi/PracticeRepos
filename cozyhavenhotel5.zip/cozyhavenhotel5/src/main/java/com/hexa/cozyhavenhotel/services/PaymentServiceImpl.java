package com.hexa.cozyhavenhotel.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import javax.swing.text.Document;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.PaymentDto;
import com.hexa.cozyhavenhotel.enums.PaymentStatus;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.repositories.PaymentRepository;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private ModelMapper modelMapper;
	private PaymentRepository paymentRepos;
	private GuestService guestService;
	private ReservationService reservationService;
	private RoomService roomService;
	@Autowired
	public PaymentServiceImpl(PaymentRepository paymentRepos, GuestService guestService,
			ReservationService reservationService
			) {
		super();
		this.paymentRepos = paymentRepos;
		this.guestService = guestService;
		this.reservationService = reservationService;
	}

	
	public Payment payNow(Long guestId,Long reservationId,PaymentDto paymentDto) throws ResourceNotFoundException {
		
		Guest guest=guestService.getGuestById(guestId);
		Reservation reservation=reservationService.getReservationById(reservationId);
		Payment payment=this.modelMapper.map(paymentDto, Payment.class);
		payment.setGuest(guest);
		payment.setReservation(reservation);
		payment.setPaymentStatus(PaymentStatus.PAID);
		return this.paymentRepos.save(payment);

	}
	
	
	
	public List<Object[]> getPendingRequestPaymentsByHotelId(Long hotelId) {
        return paymentRepos.findPendingRequestPaymentsByHotelId(hotelId);
    }
	
	public byte[] generatePaymentBill(PaymentDto paymentDto) {
	    try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        PDDocument document = new PDDocument();
	        PDPage page = new PDPage();
	        document.addPage(page);

	        PDPageContentStream contentStream = new PDPageContentStream(document, page);
	        contentStream.setFont(PDType1Font.HELVETICA, 12);
	        contentStream.beginText();
	        contentStream.newLineAtOffset(25, 700);
	        contentStream.showText("Payment Bill");
	        contentStream.newLineAtOffset(0, -15);
	        contentStream.showText("Amount Paid: " + paymentDto.getAmount());
	        contentStream.newLineAtOffset(0, -15);
	        contentStream.showText("Payment Status: "+paymentDto.getPaymentStatus());
	        contentStream.newLineAtOffset(0, -15);
	        contentStream.showText("Payment Date: " + paymentDto.getPaymentDate());
	        contentStream.endText();
	        contentStream.close();

	        document.save(outputStream);
	        document.close();

	        return outputStream.toByteArray();
	    } catch (IOException e) {
	        e.printStackTrace();
	        return null; // Consider throwing a custom exception instead
	    }
	}

	 public Payment getPaymentById(Long paymentId) throws ResourceNotFoundException {
	        // Fetch the Payment entity from the repository
	        Payment payment = paymentRepos.findById(paymentId)
	                .orElseThrow(() -> new ResourceNotFoundException("Payment","PaymentId",paymentId));

	        // Map the Payment entity to PaymentDto using ModelMapper
	        return payment;
	    }
	 
	
	}


