package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.ReservationStatus;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Room;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public class ReservationDto {
	
	private RoomDto roomDto;
	private GuestDto guestDto;

	private Long reservationId;
    private LocalDate startDate;
    private LocalDate endDate;
    
    private Integer numberOfPersons;
    private Integer numberOfRooms;
private Integer numberOfAdults;
private Integer numberOfChildren;


    public Integer getNumberOfAdults() {
	return numberOfAdults;
}



public void setNumberOfAdults(Integer numberOfAdults) {
	this.numberOfAdults = numberOfAdults;
}



public Integer getNumberOfChildren() {
	return numberOfChildren;
}



public void setNumberOfChildren(Integer numberOfChildren) {
	this.numberOfChildren = numberOfChildren;
}

	@Enumerated(EnumType.STRING)
    private ReservationStatus reservationStatus;

    
    
	public ReservationDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	 public ReservationDto(RoomDto roomDto, GuestDto guestDto, Long reservationId, LocalDate startDate,
			LocalDate endDate, Integer numberOfPersons, Integer numberOfRooms, Integer numberOfAdults,
			Integer numberOfChildren, ReservationStatus reservationStatus) {
		super();
		this.roomDto = roomDto;
		this.guestDto = guestDto;
		this.reservationId = reservationId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.numberOfAdults = numberOfAdults;
		this.numberOfChildren = numberOfChildren;
		this.reservationStatus = reservationStatus;
	}



	public ReservationDto(RoomDto roomDto, GuestDto guestDto, Long reservationId, LocalDate startDate,
			LocalDate endDate, Integer numberOfPersons, Integer numberOfRooms, ReservationStatus reservationStatus) {
		super();
		this.roomDto = roomDto;
		this.guestDto = guestDto;
		this.reservationId = reservationId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.reservationStatus = reservationStatus;
	}



	public ReservationDto(LocalDate startDate, LocalDate endDate, Integer numberOfPersons,
				Integer numberOfRooms, ReservationStatus reservationStatus) {
	    	super();
			this.startDate = startDate;
			this.endDate = endDate;
			
			this.numberOfPersons = numberOfPersons;
			this.numberOfRooms = numberOfRooms;
			this.reservationStatus = reservationStatus;
	    }
		
	
	public Long getReservationId() {
		return reservationId;
	}



	public void setReservationId(Long reservationId) {
		this.reservationId = reservationId;
	}



	public GuestDto getGuestDto() {
		return guestDto;
	}

	public void setGuestDto(GuestDto guestDto) {
		this.guestDto = guestDto;
	}

	public RoomDto getRoomDto() {
		return roomDto;
	}

	public void setRoomDto(RoomDto roomDto) {
		this.roomDto = roomDto;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	

	public Integer getNumberOfPersons() {
		return numberOfPersons;
	}

	public void setNumberOfPersons(Integer numberOfPersons) {
		this.numberOfPersons = numberOfPersons;
	}

	public Integer getNumberOfRooms() {
		return numberOfRooms;
	}

	public void setNumberOfRooms(Integer numberOfRooms) {
		this.numberOfRooms = numberOfRooms;
	}

	public ReservationStatus getReservationStatus() {
		return reservationStatus;
	}

	public void setReservationStatus(ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
    
    
}
