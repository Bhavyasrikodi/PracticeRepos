package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Hotel;

public class ReviewDto {

	private Long reviewId;
	private Double rating;  // Rating from 1 to 5
    private String reviewText;
    private LocalDate reviewDate;
    private GuestDto guestDto;
    private HotelDto hotelDto;
    
    
	public ReviewDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ReviewDto(Long reviewId, Double rating, String reviewText, LocalDate reviewDate, GuestDto guestDto,
			HotelDto hotelDto) {
		super();
		this.reviewId = reviewId;
		this.rating = rating;
		this.reviewText = reviewText;
		this.reviewDate = reviewDate;
		this.guestDto = guestDto;
		this.hotelDto = hotelDto;
	}
	
	

	
	public Long getReviewId() {
		return reviewId;
	}

	public void setReviewId(Long reviewId) {
		this.reviewId = reviewId;
	}

	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	public LocalDate getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(LocalDate reviewDate) {
		this.reviewDate = reviewDate;
	}
	public GuestDto getGuestDto() {
		return guestDto;
	}
	public void setGuestDto(GuestDto guestDto) {
		this.guestDto = guestDto;
	}
	public HotelDto getHotelDto() {
		return hotelDto;
	}
	public void setHotelDto(HotelDto hotelDto) {
		this.hotelDto = hotelDto;
	}
}
