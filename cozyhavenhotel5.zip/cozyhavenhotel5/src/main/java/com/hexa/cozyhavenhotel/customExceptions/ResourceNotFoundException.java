package com.hexa.cozyhavenhotel.customExceptions;

public class ResourceNotFoundException extends Exception {
	private String resourceName;
	private String fieldName;
	private Long fieldValue;

	
	public ResourceNotFoundException(String resourceName, String fieldName, Long fieldValue) {
		super();
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}
	public ResourceNotFoundException(String resourceName, String fieldName) {
		// TODO Auto-generated constructor stub
		super();
		this.resourceName = resourceName;
		this.fieldName = fieldName;
		
	}
	
	public String getMessage() {
		return this.resourceName+" is not found with "+this.fieldName+" value "+this.fieldValue;
		
	}
	
}