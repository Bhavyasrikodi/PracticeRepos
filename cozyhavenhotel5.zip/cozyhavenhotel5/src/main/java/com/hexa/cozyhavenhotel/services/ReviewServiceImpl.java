package com.hexa.cozyhavenhotel.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;

import com.hexa.cozyhavenhotel.dtos.GuestDto;
import com.hexa.cozyhavenhotel.dtos.HotelDto;
import com.hexa.cozyhavenhotel.dtos.HotelOwnerDto;
import com.hexa.cozyhavenhotel.dtos.ReviewDto;
import com.hexa.cozyhavenhotel.dtos.UserDto;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.Review;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;
import com.hexa.cozyhavenhotel.repositories.ReviewRepository;
@Service
public class ReviewServiceImpl implements ReviewService{
	@Autowired
	private ModelMapper modelMapper;
	private ReviewRepository reviewRepos;
	private GuestService guestService;
	private HotelService hotelService;
	
	private HotelOwnerService hotelOwnerService;
	private HotelOwnerRepository hotelOwnerRepos;
	
	
	@Autowired
	
	public ReviewServiceImpl(ReviewRepository reviewRepos, GuestService guestService, HotelService hotelService,
			 HotelOwnerService hotelOwnerService, HotelOwnerRepository hotelOwnerRepos
			) {
		super();
		this.reviewRepos = reviewRepos;
		this.guestService = guestService;
		this.hotelService = hotelService;
		
		this.hotelOwnerService = hotelOwnerService;
		this.hotelOwnerRepos = hotelOwnerRepos;
		
	}
	
	
	@Override
	public Review rateNow(ReviewDto reviewDto, Long guestId, Long hotelId) throws ResourceNotFoundException {
		
		Guest guest=guestService.getGuestById(guestId);
		Hotel hotel=hotelService.getHotelById(hotelId);
		Review review=this.modelMapper.map(reviewDto, Review.class);
		review.setGuest(guest);
		review.setHotel(hotel);
		return this.reviewRepos.save(review);

		
	}


	
}
