package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.Role;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;

public class UserDto {
	@Column(nullable = false)
	private String username;

	private String password; 

	@NotNull
	@Enumerated(EnumType.STRING)
	private Role role;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public UserDto(String username, String password, @NotNull Role role) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
	}

	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
