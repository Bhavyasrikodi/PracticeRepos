package com.hexa.cozyhavenhotel.services;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

}
