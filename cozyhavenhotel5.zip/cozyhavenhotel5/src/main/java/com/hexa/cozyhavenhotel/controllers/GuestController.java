package com.hexa.cozyhavenhotel.controllers;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.GuestDto;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.services.GuestService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/guest")
@CrossOrigin("http://localhost:3000")
public class GuestController {
	private final GuestService guestService;
	
	private final ModelMapper modelMapper;
	public GuestController(GuestService guestService,ModelMapper modelMapper) {
		this.guestService = guestService;
		this.modelMapper= modelMapper;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('HOTEL_OWNER')")
	@GetMapping("/getguestid")
	public ResponseEntity<GuestDto> findById(@Valid @RequestParam("guestId") long guestId)throws ResourceNotFoundException{
		Guest guest=this.guestService.getGuestById(guestId);
		GuestDto guestDto=this.modelMapper.map(guest,GuestDto.class);
		guestDto.setRole(guest.getUser().getRole());
		return ResponseEntity.ok(guestDto);
	}
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getAllGuests")
	public ResponseEntity<List<GuestDto>> getAllGuests(){
		List<GuestDto> listOfGuests=new ArrayList<>();
		List<Guest> guests=this.guestService.getAllGuests();
		for(Guest guest:guests) {
			GuestDto guestDto=this.modelMapper.map(guest, GuestDto.class);
			listOfGuests.add(guestDto);
		}
		return ResponseEntity.ok(listOfGuests);
	}
	@PreAuthorize("hasRole('GUEST')")
	@GetMapping("/getguestidbyusername")
	public Long getGuestId(@Valid @RequestParam String username) {
		return this.guestService.getGuestId(username);
	}
	
}