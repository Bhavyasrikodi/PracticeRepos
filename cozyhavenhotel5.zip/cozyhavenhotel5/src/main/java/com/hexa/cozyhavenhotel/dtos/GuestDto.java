package com.hexa.cozyhavenhotel.dtos;

import com.hexa.cozyhavenhotel.enums.Role;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class GuestDto {
	
	private Long guestId;
	@NotNull
	@Size(min = 2, max = 50)
    private String guestName;
    @NotNull
    @Email
    private String email;
    @NotNull
    private String phoneNumber;
    @NotNull
	@Pattern(regexp = "^(Male|Female|Other)$")
	private String gender;
    @NotNull
    private String aadharNumber;
    
    @Enumerated(EnumType.STRING)
	private Role role;

    
    
	public Long getGuestId() {
		return guestId;
	}

	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	

	public GuestDto(Long guestId, @NotNull @Size(min = 2, max = 50) String guestName, @NotNull @Email String email,
			@NotNull String phoneNumber, @NotNull @Pattern(regexp = "^(Male|Female|Other)$") String gender,
			@NotNull String aadharNumber, Role role) {
		super();
		this.guestId = guestId;
		this.guestName = guestName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.aadharNumber = aadharNumber;
		this.role = role;
	}

	public GuestDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}