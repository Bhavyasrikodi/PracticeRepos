package com.hexa.cozyhavenhotel.dtos;


public class UserResponseDto {
	private AdminDto admin;
    private GuestDto guest;
    private HotelOwnerDto hotelOwner;
    private UserDto user;
	public UserDto getUser() {
		return user;
	}
	public void setUser(UserDto user) {
		this.user = user;
	}
	public AdminDto getAdmin() {
		return admin;
	}
	public void setAdmin(AdminDto admin) {
		this.admin = admin;
	}
	public GuestDto getGuest() {
		return guest;
	}
	public void setGuest(GuestDto guest) {
		this.guest = guest;
	}
	public HotelOwnerDto getHotelOwner() {
		return hotelOwner;
	}
	public void setHotelOwner(HotelOwnerDto hotelOwner) {
		this.hotelOwner = hotelOwner;
	}
	public UserResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserResponseDto(AdminDto admin, GuestDto guest, HotelOwnerDto hotelOwner,UserDto user) {
		super();
		this.admin = admin;
		this.guest = guest;
		this.hotelOwner = hotelOwner;
		this.user =user;
	}
    
    

}
