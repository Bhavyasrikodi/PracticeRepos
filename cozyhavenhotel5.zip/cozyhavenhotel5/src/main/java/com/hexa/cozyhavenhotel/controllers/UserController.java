
package com.hexa.cozyhavenhotel.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.dtos.AdminDto;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.dtos.GuestDto;
import com.hexa.cozyhavenhotel.dtos.HotelOwnerDto;
import com.hexa.cozyhavenhotel.dtos.UserDto;
import com.hexa.cozyhavenhotel.dtos.UserResponseDto;
import com.hexa.cozyhavenhotel.models.Admin;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.repositories.UserRepository;
import com.hexa.cozyhavenhotel.services.AdminService;
import com.hexa.cozyhavenhotel.services.GuestService;
import com.hexa.cozyhavenhotel.services.HotelOwnerService;
import com.hexa.cozyhavenhotel.services.UserService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private UserService userService;
	@Autowired
	private GuestService guestService;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private HotelOwnerService hotelOwnerService;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private ModelMapper modelMapper;
	


	@GetMapping("/user/hello")
	public String userHello() {
		return "Hello, User!";
	}

	@GetMapping("/admin/hello")
	public String adminHello() {
		return "Hello, Admin!";
	}

	@PostMapping("/auth/signup")
	public ResponseEntity<String> createUser(@Valid @RequestBody AdminGuestOwnerDto adminGuestOwnerDto) {

	    String role = adminGuestOwnerDto.getRole().name();
	    
		UserResponseDto userResponseDto=new UserResponseDto();
	    
	    if ("ADMIN".equalsIgnoreCase(role)) { 
	        // Handle Admin signup
	    	if(userRepository.existsByUsername(adminGuestOwnerDto.getUsername())) {
				return ResponseEntity.ok("username already exists");
			}else {
	        Admin admin = this.adminService.createAdmin(adminGuestOwnerDto); // Reuse the same DTO
	        AdminDto adminDto = this.modelMapper.map(admin, AdminDto.class);
	        userResponseDto.setAdmin(adminDto);}

	    } else if ("GUEST".equalsIgnoreCase(role)) {
	        // Handle Guest signup
	    	if(userRepository.existsByUsername(adminGuestOwnerDto.getUsername())) {
				return ResponseEntity.ok("username already exists");
			}else {
	        Guest guest = this.guestService.createGuest(adminGuestOwnerDto); // Reuse the same DTO
	        GuestDto guestDto = this.modelMapper.map(guest, GuestDto.class);
	        userResponseDto.setGuest(guestDto);}

	    } else if ("HOTEL_OWNER".equalsIgnoreCase(role)) {
	        // Handle Hotel Owner signup
	    	if(userRepository.existsByUsername(adminGuestOwnerDto.getUsername())) {
				return ResponseEntity.ok("username already exists");
			}else {
	        HotelOwner hotelOwner = this.hotelOwnerService.createOwner(adminGuestOwnerDto); // Reuse the same DTO
	        HotelOwnerDto hotelOwnerDto = this.modelMapper.map(hotelOwner, HotelOwnerDto.class);
	        userResponseDto.setHotelOwner(hotelOwnerDto);}

	    } else {
	        throw new IllegalArgumentException("Invalid user role");
	    }

	    // Common user details mapping
	    UserDto commonUserDto = this.modelMapper.map(adminGuestOwnerDto, UserDto.class);
	    userResponseDto.setUser(commonUserDto);

	    return ResponseEntity.ok("Registration successful!!");
	}

	
}
