package com.hexa.cozyhavenhotel.dtos;


import com.hexa.cozyhavenhotel.enums.Role;
import com.hexa.cozyhavenhotel.models.User;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AdminGuestOwnerDto {
	


    private String adminName;

    private String email;

    private  String phoneNumber;

    private String adminLevel;
    

    private String guestName;

	private String gender;
	

    private String guestAddress;
    

    private String hotelOwnerName;
    

    private String businessLicense;
    

	private String username;

	private String password; 


	private Role role;
	
	private String aadharNumber;

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAdminLevel() {
		return adminLevel;
	}

	public void setAdminLevel(String adminLevel) {
		this.adminLevel = adminLevel;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGuestAddress() {
		return guestAddress;
	}

	public void setGuestAddress(String guestAddress) {
		this.guestAddress = guestAddress;
	}

	public String getHotelOwnerName() {
		return hotelOwnerName;
	}

	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}

	public String getBusinessLicense() {
		return businessLicense;
	}

	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public AdminGuestOwnerDto(String adminName, String email, String phoneNumber, String adminLevel, String guestName,
			String gender, String guestAddress, String hotelOwnerName, String businessLicense, String username,
			String password, Role role,String aadharNumber) {
		super();
		this.adminName = adminName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.adminLevel = adminLevel;
		this.guestName = guestName;
		this.gender = gender;
		this.guestAddress = guestAddress;
		this.hotelOwnerName = hotelOwnerName;
		this.businessLicense = businessLicense;
		this.username = username;
		this.password = password;
		this.role = role;
		this.aadharNumber=aadharNumber;
	}

	public AdminGuestOwnerDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	

}
