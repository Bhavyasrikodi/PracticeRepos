package com.hexa.cozyhavenhotel.controllers;


import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.HttpHeaders;
import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.PaymentDto;
import com.hexa.cozyhavenhotel.dtos.PaymentOutputDto;
import com.hexa.cozyhavenhotel.models.Payment;
import com.hexa.cozyhavenhotel.services.PaymentService;
import org.springframework.http.MediaType;



import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/payment")

@CrossOrigin("http://localhost:3000")
public class PaymentController {
	
	private final ModelMapper modelMapper;
	private final PaymentService paymentService;
	@Autowired
	public PaymentController(PaymentService paymentService,ModelMapper modelMapper) {
		super();
		this.paymentService = paymentService;
		this.modelMapper=modelMapper;
	}
	
	@PreAuthorize("hasRole('GUEST')")
	@PostMapping("/paynow")
	public ResponseEntity<PaymentOutputDto> payNow(@Valid @RequestParam  Long guestId,@RequestParam Long reservationId,@RequestBody PaymentDto paymentDto)throws ResourceNotFoundException{
		Payment payment=this.paymentService.payNow(guestId,reservationId,  paymentDto);
		PaymentOutputDto paymentOutputdto=this.modelMapper.map(payment,PaymentOutputDto.class);
		paymentOutputdto.setReservationStatus(payment.getReservation().getReservationStatus());
		paymentOutputdto.setRoomNumber(payment.getReservation().getRoom().getRoomNumber());
		paymentOutputdto.setHotelName(payment.getReservation().getRoom().getHotel().getHotelName());
		paymentOutputdto.setGuestName(payment.getGuest().getGuestName());
		paymentOutputdto.setPhoneNumber(payment.getGuest().getPhoneNumber());
		return ResponseEntity.ok(paymentOutputdto);
			
	}
	
	@GetMapping("/pendingrequests")
    public ResponseEntity<List<Object[]>> getPendingRequestPaymentsByHotel(@RequestParam("hotelId") Long hotelId) {
        List<Object[]> pendingRequestPayments = paymentService.getPendingRequestPaymentsByHotelId(hotelId);
        if (pendingRequestPayments.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pendingRequestPayments);
    }
	
	@GetMapping("/downloadbill")
	public ResponseEntity<byte[]> downloadPaymentBill(@RequestParam Long paymentId) throws ResourceNotFoundException {
	    // Fetch the payment details using the service
	    Payment payment = paymentService.getPaymentById(paymentId);
	    PaymentDto paymentDto = this.modelMapper.map(payment, PaymentDto.class);
	    
	    if (paymentDto == null) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }

	    // Generate the payment bill PDF as byte array
	    byte[] pdfBytes = paymentService.generatePaymentBill(paymentDto);
	    if (pdfBytes == null) {
	        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // Handle the error appropriately
	    }

	    // Set headers to indicate file download
	    HttpHeaders headers = new HttpHeaders();
	    headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=PaymentBill_" + paymentId + ".pdf");
	    headers.setContentType(MediaType.APPLICATION_PDF);

	    // Return the PDF as a byte array in the response
	    return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
	}

}
