package com.hexa.cozyhavenhotel.enums;

public enum Role {
	 ADMIN,
	    HOTEL_OWNER,
	    GUEST
}
