package com.hexa.cozyhavenhotel.controllers;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.HotelOwnerDto;
import com.hexa.cozyhavenhotel.dtos.ReservationOutputDto;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.services.HotelOwnerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/havenstay/owner")
@CrossOrigin("http://localhost:3000")
public class HotelOwnerController {

	private final HotelOwnerService hotelOwnerService;
	private final ModelMapper modelMapper;
	@Autowired
	public HotelOwnerController(HotelOwnerService hotelOwnerService,ModelMapper modelMapper) {
		super();
		this.hotelOwnerService = hotelOwnerService;
		this.modelMapper = new ModelMapper();
	}
	

	@GetMapping("/getHotelOwnerbyid")
	public ResponseEntity<HotelOwnerDto> findById(@Valid @RequestParam Long ownerId) throws ResourceNotFoundException {
		HotelOwner hotelOwner=this.hotelOwnerService.getOwnerById(ownerId);
		HotelOwnerDto hotelOwnerDto=this.modelMapper.map(hotelOwner, HotelOwnerDto.class);
		hotelOwnerDto.setRole(hotelOwner.getUser().getRole());
		return ResponseEntity.ok(hotelOwnerDto);
		
	}
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/getAllOwners")
	public ResponseEntity<List<HotelOwnerDto>> getAllOwners(){
		List<HotelOwnerDto>listOfOwners=new ArrayList<>();
		List<HotelOwner> hotelOwners=this.hotelOwnerService.getAllOwners();
		
		for(HotelOwner owner: hotelOwners) {
			HotelOwnerDto hotelOwnerDto=this.modelMapper.map(owner, HotelOwnerDto.class);
			//hotelOwnerDto.setRole(hotelOwners.getUser().getRole());
			listOfOwners.add(hotelOwnerDto);
		}
		return ResponseEntity.ok(listOfOwners);
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getReservationsOfParticularHotel")
	public List<ReservationOutputDto> getReservationsOfHotel(@RequestParam("hotelId") Long hotelId){
		List<ReservationOutputDto> reservationDtoList=this.hotelOwnerService.getReservationsOfHotel(hotelId);
		return reservationDtoList;
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getGuestsOfParticularHotel")
	public List<Guest> getGuestsOfHotel(@RequestParam("hotelId") Long hotelId){
		List<Guest> guestList=this.hotelOwnerService.getGuestsOfHotel(hotelId);
		return guestList;
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getRoomsOfParticularHotel")
	public List<Room> getRoomsOfHotel(@RequestParam("hotelId") Long hotelId){
		List<Room> roomList=this.hotelOwnerService.getRoomsOfHotel(hotelId);
		return roomList;
	}
	
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getHotelId")
	public Long getHotelId(@RequestParam("username") String username) {
		return this.hotelOwnerService.getHotelId(username);
	}
	
	
	

	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/pendingrequests")
    public ResponseEntity<List<Object[]>> getPendingRequestPaymentsByHotel(@RequestParam("hotelId") Long hotelId) {
        List<Object[]> pendingRequestPayments = hotelOwnerService.getPendingRequestPaymentsByHotelId(hotelId);
        if (pendingRequestPayments.isEmpty()) {
            return ResponseEntity.noContent().build();
            }
        return ResponseEntity.ok(pendingRequestPayments);
     }
	
	@GetMapping("/getUsernameById")
	public String getUsernameByName(@RequestParam("guestId") Long guestId) {
		return this.hotelOwnerService.findUsernameById(guestId);
	}
	
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getOwneridbyUsername")
	public Long getOwnerId(@RequestParam("username") String username) {
		return this.hotelOwnerService.getOwnerid(username);
	}
	@PreAuthorize("hasRole('HOTEL_OWNER')")
	@GetMapping("/getAllReviewsOfHotel")
	public ResponseEntity<List<Object[]>> getAllReviewsOfHotel(@RequestParam Long hotelId){
		List<Object[]> reviews = hotelOwnerService.getHotelReviews(hotelId);
		return ResponseEntity.ok(reviews);
	}
}
