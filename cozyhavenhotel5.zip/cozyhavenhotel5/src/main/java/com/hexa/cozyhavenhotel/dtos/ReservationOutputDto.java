package com.hexa.cozyhavenhotel.dtos;

import java.time.LocalDate;

import com.hexa.cozyhavenhotel.enums.BedPreferences;
import com.hexa.cozyhavenhotel.enums.ReservationStatus;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public class ReservationOutputDto {
	
	private Long reservationId;
	private Long roomId;
	private Long guestId;
	private LocalDate startDate;
    private LocalDate endDate;
    
    private Integer numberOfPersons;
    private Integer numberOfRooms;
    private Double totalPrice;
    @Enumerated(EnumType.STRING)
    private ReservationStatus reservationStatus;
    
    private String roomNumber;
    @Enumerated(EnumType.STRING)
    private BedPreferences bedPreferences;
    private String hotelName;
    private String location;
    private String hotelOwnerName;
    private String businessLicense;
    private String guestName;
    private String phoneNumber;
	
    public Long getRoomId() {
		return roomId;
	}
	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}
	public Long getGuestId() {
		return guestId;
	}
	public void setGuestId(Long guestId) {
		this.guestId = guestId;
	}
	
    
    
	public Long getReservationId() {
		return reservationId;
	}
	public void setReservationId(Long reservationId) {
		this.reservationId = reservationId;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Integer getNumberOfPersons() {
		return numberOfPersons;
	}
	public void setNumberOfPersons(Integer numberOfPersons) {
		this.numberOfPersons = numberOfPersons;
	}
	public Integer getNumberOfRooms() {
		return numberOfRooms;
	}
	public void setNumberOfRooms(Integer numberOfRooms) {
		this.numberOfRooms = numberOfRooms;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public ReservationStatus getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(ReservationStatus reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public BedPreferences getBedPreferences() {
		return bedPreferences;
	}
	public void setBedPreferences(BedPreferences bedPreferences) {
		this.bedPreferences = bedPreferences;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getHotelOwnerName() {
		return hotelOwnerName;
	}
	public void setHotelOwnerName(String hotelOwnerName) {
		this.hotelOwnerName = hotelOwnerName;
	}
	public String getBusinessLicense() {
		return businessLicense;
	}
	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public ReservationOutputDto(Long reservationId, LocalDate startDate, LocalDate endDate, Integer numberOfPersons,
			Integer numberOfRooms, Double totalPrice, ReservationStatus reservationStatus, String roomNumber,
			BedPreferences bedPreferences, String hotelName, String location, String hotelOwnerName,
			String businessLicense, String guestName, String phoneNumber) {
		super();
		this.reservationId = reservationId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.totalPrice = totalPrice;
		this.reservationStatus = reservationStatus;
		this.roomNumber = roomNumber;
		this.bedPreferences = bedPreferences;
		this.hotelName = hotelName;
		this.location = location;
		this.hotelOwnerName = hotelOwnerName;
		this.businessLicense = businessLicense;
		this.guestName = guestName;
		this.phoneNumber = phoneNumber;
	}
	
	public ReservationOutputDto(Long roomId, Long guestId, Long reservationId, LocalDate startDate, LocalDate endDate,
			Integer numberOfPersons, Integer numberOfRooms, ReservationStatus reservationStatus, Double totalPrice) {
		super();
		this.roomId = roomId;
		this.guestId = guestId;
		this.reservationId = reservationId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numberOfPersons = numberOfPersons;
		this.numberOfRooms = numberOfRooms;
		this.reservationStatus = reservationStatus;
		this.totalPrice = totalPrice;
	}
	public ReservationOutputDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
}