package com.hexa.cozyhavenhotel.services;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.ReviewDto;
import com.hexa.cozyhavenhotel.models.Review;

public interface ReviewService {
 public Review rateNow(ReviewDto reviewDto, Long guestId, Long hotelId)throws ResourceNotFoundException ;
}
