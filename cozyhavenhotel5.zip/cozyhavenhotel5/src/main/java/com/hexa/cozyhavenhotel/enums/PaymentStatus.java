package com.hexa.cozyhavenhotel.enums;

public enum PaymentStatus {
	PAID,
    PENDING_REFUND,
    REFUNDED

}
