package com.hexa.cozyhavenhotel.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.User;
import com.hexa.cozyhavenhotel.repositories.GuestRepository;
import com.hexa.cozyhavenhotel.repositories.UserRepository;

@Service
public class GuestServiceImpl implements GuestService{
	private GuestRepository guestRepos;
	private UserRepository userRepository;
	@Autowired
	public GuestServiceImpl(GuestRepository guestRepos, UserRepository userRepository) {
		super();
		this.guestRepos = guestRepos;
		this.userRepository = userRepository;
	}
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Override
	public Guest createGuest(AdminGuestOwnerDto adminGuestOwnerDto) {
		Guest guest=this.modelMapper.map(adminGuestOwnerDto, Guest.class);
		User user=this.modelMapper.map(adminGuestOwnerDto,User.class);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		guest.setUser(user);
		this.userRepository.save(user);
		return this.guestRepos.save(guest);
		
	}
	@Override
	public Guest getGuestById(Long guestId)throws ResourceNotFoundException{
		Guest guest=this.guestRepos.findById(guestId).orElseThrow(()->new ResourceNotFoundException("guest","id",guestId));
		 return guest;
	}


	@Override
	public List<Guest> getAllGuests(){
		return this.guestRepos.findAll();
	}
	@Override
	public Long getGuestId(String username) {
		return this.guestRepos.getGuestId(username);
	}
}
