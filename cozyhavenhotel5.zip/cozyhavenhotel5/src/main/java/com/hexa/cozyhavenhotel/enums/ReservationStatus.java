package com.hexa.cozyhavenhotel.enums;

public enum ReservationStatus {
	BOOKED,
    CANCELLED
}
