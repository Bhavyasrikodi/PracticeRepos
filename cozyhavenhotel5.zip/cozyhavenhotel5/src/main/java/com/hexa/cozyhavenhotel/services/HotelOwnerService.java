package com.hexa.cozyhavenhotel.services;


import java.util.List;

import com.hexa.cozyhavenhotel.customExceptions.ResourceNotFoundException;
import com.hexa.cozyhavenhotel.dtos.AdminGuestOwnerDto;
import com.hexa.cozyhavenhotel.dtos.ReservationOutputDto;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Review;
import com.hexa.cozyhavenhotel.models.Room;

public interface HotelOwnerService {

	public HotelOwner createOwner(AdminGuestOwnerDto adminGuestOwnerDto);
	public HotelOwner getOwnerById(Long ownerId)throws ResourceNotFoundException;
	public List<HotelOwner> getAllOwners();
	public List<ReservationOutputDto> getReservationsOfHotel(Long hotelId);
	public List<Guest> getGuestsOfHotel(Long hotelId);
	public List<Room> getRoomsOfHotel(Long hotelId);
	public Long getHotelId(String username);
//	public List<PaymentOutputDto> getRefundList(String paymentStatus,Long hotelId);
	 public List<Object[]> getPendingRequestPaymentsByHotelId(Long hotelId);
	 public String findUsernameById(Long guestId);
	 public Long getOwnerid(String username);
	 public List<Object[]>  getHotelReviews(Long hotelId);
}
