package com.hexa.cozyhavenhotel.testing;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.cozyhavenhotel.models.HotelOwner;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.repositories.HotelOwnerRepository;

@SpringBootTest
public class HotelOwnerTest {
	@Autowired
	private HotelOwnerRepository hotelOwnerRepos;
	@Disabled
	@Test
	void createOwnerTest() {
		HotelOwner hotelOwner=new HotelOwner("Tej","tej@gmail.com","8654321980","Fssai");
		HotelOwner savedOwner=hotelOwnerRepos.save(hotelOwner);
	}
	@Disabled
	@Test
	void findOwnerByIdTest(){
		Long ownerId=1L;
		@SuppressWarnings("deprecation")
		HotelOwner hotelOwner=hotelOwnerRepos.getById(ownerId);
	}
	@Disabled
	@Test
	void findAllOwnersTest() {
		hotelOwnerRepos.findAll();
	}
	@Disabled
	@Test
	void getReservationsOfHotelTest() {
		Long hotelId=1L;
		List<Object[]> reservation=hotelOwnerRepos.getRawReservationsOfHotel(hotelId);
		
	}
	@Disabled
	@Test
	void getGuestOfHotelTest() {
		Long hotelId=1L;
		List<Object[]> guest=hotelOwnerRepos.getRawGuestsOfHotel(hotelId);
		
	}
	@Disabled
	@Test
	void getRoomsOfHotelTest() {
		Long hotelId=1L;
		List<Object[]> room=hotelOwnerRepos.getRawRoomsOfHotel(hotelId);
		
	}
	
	
	
}

