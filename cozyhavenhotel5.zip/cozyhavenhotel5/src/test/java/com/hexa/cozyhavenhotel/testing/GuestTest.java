package com.hexa.cozyhavenhotel.testing;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.hexa.cozyhavenhotel.models.Guest;

import com.hexa.cozyhavenhotel.repositories.GuestRepository;

@SpringBootTest
public class GuestTest {
	@Autowired 
	private GuestRepository guestRepos;
	//endDate,totalPrice,numberOfPersons,numberOfRooms,numberOfAdults,numberOfChildren,reservationStatus,startDate
	@Disabled
	@Test
	void createGuestTest() {
		Guest guest=new Guest("Bhavyasri","sri@gmail.com","9234567819","Female","Tirupati","202030665412");
		Guest savedGuest=guestRepos.save(guest);
	}
	@Disabled
	@Test
	void findGuestByIdTest() {
		Long guestId=1L;
		@SuppressWarnings("deprecation")
		Guest guest=guestRepos.getById(guestId);
	}
	@Disabled
	@Test
	void findAllGuestsTest() {
		guestRepos.findAll();
	}
	@Disabled
	@Test
	void getGuestIdTest() {
		String username="Bhavya";
		Long guest=guestRepos.getGuestId(username);
		
	}
//	@Test
//	void updateBookbyisbnTest() {
//		Long id=1L;
//		String isbn="T105";
//		Book book=bookRepository.findById(id).get();
//		book.setAuthor("Ram");
//		book.setPublicationYear(2022);
//		book.setIsbn("T108");
//		book.setTitle("python");
//	}
//	@Test
//	void deleteByIdTest() {
//		Long id=24L;
//		productRepository.deleteById(id);
//	}
}
