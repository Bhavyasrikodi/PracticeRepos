package com.hexa.cozyhavenhotel.testing;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.cozyhavenhotel.enums.BedPreferences;
import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.models.Room;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;
import com.hexa.cozyhavenhotel.repositories.ReservationRepository;
import com.hexa.cozyhavenhotel.repositories.RoomRepository;

@SpringBootTest
public class RoomTest {
	@Autowired
	private RoomRepository roomRepos;
	@Autowired
	private HotelRepository hotelRepos;
	@Autowired
	private ReservationRepository reservationRepos;
	@Disabled
	@Test
	void addRoomTest() {
		Long hotelOwnerId=1L;
		Long hotelId=1L;
		Room room=new Room("B107",500.00,2,true,true,BedPreferences.SINGLE);
		Room savedRoom=roomRepos.save(room);
	}
	@Disabled
	@Test
	void createMultipleRoomsTest() {
		Room room1 = new Room("B107", 500.00, 2, true, true, BedPreferences.SINGLE);
        Room room2 = new Room("B108", 600.00, 3, true, true, BedPreferences.DOUBLE);
        //List<Room> savedRooms = roomService.creatMultipleRoom(hotelId, roomDtos);
        List<Room> listOfRooms=new ArrayList<>();
        listOfRooms=roomRepos.saveAll(List.of(room1,room2)); 
	}
	
	@Test
	void getRoomByIdTest() {
		Long roomId=1L;
		
		Room room=roomRepos.findById(roomId).get();
	}
	
	@Test
	void editRoomTest() {
		Long hotelOwnerId=1L;
		Long hotelId=1L;
		Long roomId=1L;
		Room room=roomRepos.findById(roomId).get();
		room.setAvailability(false);
		room.setBaseFare(500.00);
		room.setBedPreferences(BedPreferences.SINGLE);
		room.setIsAc(true);
		room.setMaxOccupancy(2);
		room.setRoomNumber("B107");	
	}
	
	@Test
	void getRoomsByHotelIdTest() {
		Long hotelId=1L;
		List<Room> rooms=roomRepos.findByHotelId(hotelId);
	}
	
	@Test
	void findAvailableRoomsInLocationTest() {
		String location="hyderabad";
		LocalDate startDate=LocalDate.parse("2024-09-25");
		LocalDate endDate=LocalDate.parse("2024-09-26");
		List<Hotel> rooms=hotelRepos.findHotelsWithAvailableRooms(location, startDate, endDate);
	}
	
	
}
