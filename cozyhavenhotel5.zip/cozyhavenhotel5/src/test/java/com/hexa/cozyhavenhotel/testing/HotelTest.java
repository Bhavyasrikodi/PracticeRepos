package com.hexa.cozyhavenhotel.testing;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.cozyhavenhotel.models.Hotel;
import com.hexa.cozyhavenhotel.repositories.HotelRepository;

@SpringBootTest
public class HotelTest {
	@Autowired
	private HotelRepository hotelRepos;
	@Disabled
	@Test
	void createHotelTest() {
		Hotel hotel=new Hotel("GrandHyatt","Hyderabad",true,false,true,false,true,true,"hotel.img",4.50);
		Hotel savedHotel=hotelRepos.save(hotel);
	}
	@Disabled
	@Test
	void getHotelByIdTest() {
		Long hotelId=1L;
		@SuppressWarnings("deprecation")
		Hotel hotel=hotelRepos.getById(hotelId);
	}
	@Disabled
	@Test
	void getHotelByLocationTest() {
		String location="Hyderabad";
		List<Hotel> hotel=hotelRepos.searchHotelsbylocation(location);
	}
	@Disabled
	@Test
	void getAllHotelsTest() {
		hotelRepos.findAll();
	}
	@Disabled
	@Test
	void getHotelsByDatesTest() {
		String location="Hyderabad";
		LocalDate startDate=LocalDate.parse("2024-09-25");
		LocalDate endDate=LocalDate.parse("2024-09-26");
		List<Hotel> hotel=hotelRepos.findHotelsWithAvailableRooms(location, startDate, endDate);
	}
	
	 
}
