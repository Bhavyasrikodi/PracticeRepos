package com.hexa.cozyhavenhotel.testing;

import java.time.LocalDate;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.cozyhavenhotel.enums.ReservationStatus;
import com.hexa.cozyhavenhotel.models.Reservation;
import com.hexa.cozyhavenhotel.repositories.ReservationRepository;

@SpringBootTest
public class ReservationTest {
	@Autowired
	private ReservationRepository reservationRepos;
	@Disabled
	@Test
	void reservesRoomTest() {
		Reservation reservation=new Reservation(LocalDate.parse("2024-09-25"),500.00,2,1,1,1,ReservationStatus.BOOKED,LocalDate.parse("2024-09-26"));
		Reservation savedReservation=reservationRepos.save(reservation);
	}
	@Disabled
	@Test
	void getReservationByIdTest() {
		Long reservationId=1L;
		Reservation reservation=reservationRepos.findById(reservationId).get();
		
	}
	
	
}
