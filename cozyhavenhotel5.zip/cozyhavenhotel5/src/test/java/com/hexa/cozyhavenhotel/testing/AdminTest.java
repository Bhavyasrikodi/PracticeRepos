package com.hexa.cozyhavenhotel.testing;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.cozyhavenhotel.models.Admin;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.models.Guest;
import com.hexa.cozyhavenhotel.repositories.AdminRepository;
import com.hexa.cozyhavenhotel.repositories.GuestRepository;

@SpringBootTest
public class AdminTest {
	@Autowired
	private AdminRepository adminRepos;
	@Autowired
	private GuestRepository guestRepos;
	@Disabled
	@Test
	void createAdminTest() {
		Admin admin=new Admin("Harry","harry@gmail.com","9876543212","superior");
		Admin savedAdmin=adminRepos.save(admin);
	}
	
//	@Test
//	void deleteGuestTest() {
//		Long guestId=1L;
//		Guest guest=guestRepos.getById(guestId);
//		guestRepos.delete(guest);
//	}

}
